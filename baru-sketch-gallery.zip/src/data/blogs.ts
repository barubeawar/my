import { BlogPost } from '../types';

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'blog-1',
    title: 'The Art of Hyper-Realistic Charcoal Portraits: Behind the Charcoal Dust',
    excerpt: 'Discover how artist Vishal Kumar Baroliya crafts life-like depth, expressive gaze, and intricate skin textures using raw willow charcoal.',
    content: 'Charcoal is one of humanity’s oldest artistic mediums, yet achieving hyper-realism requires painstaking patience. In this guide, artist Vishal Kumar Baroliya shares techniques on blending stump pressure, white chalk highlighting, and fixative sealing to ensure charcoal portraits last generations without fading.',
    date: 'February 10, 2026',
    readTime: '4 min read',
    imageUrl: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=800&q=80',
    category: 'Artist Technique'
  },
  {
    id: 'blog-2',
    title: 'How to Choose the Perfect Frame & Size for Your Living Room Art',
    excerpt: 'A comprehensive interior design guide on selecting dimensions, matte borders, and frame colors for oil and acrylic canvas paintings.',
    content: 'Selecting artwork for your home is an intimate expression of personal taste. For grand living room walls, 24x36 inch or 30x40 inch canvases create a striking visual anchor. Learn how floating gold frames elevate modern interiors while deep mahogany frames preserve classical warm charm.',
    date: 'January 28, 2026',
    readTime: '5 min read',
    imageUrl: 'https://images.unsplash.com/photo-1501472312651-726afe119ff1?auto=format&fit=crop&w=800&q=80',
    category: 'Interior Guide'
  },
  {
    id: 'blog-3',
    title: 'Caring for Your Original Oil & Acrylic Canvas Paintings',
    excerpt: 'Essential art preservation tips from Baru Sketch Gallery on dust removal, UV lighting protection, and ambient humidity control.',
    content: 'Original handmade oil and acrylic paintings are valuable living investments. Always hang canvas artwork away from direct harsh sunlight, dust gently with a clean dry ostrich feather or soft micro-fiber cloth, and avoid chemical solvents to maintain the original vibrant pigments for centuries.',
    date: 'December 18, 2025',
    readTime: '3 min read',
    imageUrl: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=800&q=80',
    category: 'Art Care'
  }
];
