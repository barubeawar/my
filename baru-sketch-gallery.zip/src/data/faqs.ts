import { FAQItem } from '../types';

export const FAQS: FAQItem[] = [
  {
    id: 'faq-01',
    question: 'How do I order a custom portrait or commission artwork?',
    answer: 'You can easily order a custom portrait by visiting the "Custom Artwork" section on our website. Upload your high-resolution reference photo, select your preferred dimensions (e.g. 12x18, 18x24, 24x36 inches) and medium (Pencil, Charcoal, Oil, Acrylic, Watercolor). You can also click "Order on WhatsApp" to discuss your idea directly with artist Vishal Kumar Baroliya.',
    category: 'Custom Orders'
  },
  {
    id: 'faq-02',
    question: 'Are all paintings 100% original and handmade?',
    answer: 'Yes! Every single sketch, portrait, and painting listed at Baru Sketch Gallery is 100% individually hand-drawn and hand-painted by master artist Vishal Kumar Baroliya. We never sell digital prints or mass reproductions.',
    category: 'Framing & Authenticity'
  },
  {
    id: 'faq-03',
    question: 'Does the artwork come with a Certificate of Authenticity?',
    answer: 'Yes, every original artwork and custom portrait includes an official physical Certificate of Authenticity signed and stamped by artist Vishal Kumar Baroliya, stating the title, medium, dimensions, year of creation, and unique catalog ID.',
    category: 'Framing & Authenticity'
  },
  {
    id: 'faq-04',
    question: 'How does payment work?',
    answer: 'We support free and direct payment methods including UPI (Google Pay, PhonePe, Paytm, BHIM) via direct QR code scanning or UPI ID. You can also place orders over WhatsApp where we confirm payment and send immediate digital receipts.',
    category: 'General'
  },
  {
    id: 'faq-05',
    question: 'What is the shipping time and packaging process?',
    answer: 'Domestic orders across India are delivered within 4–7 business days via insured express couriers (Bluedart / DTDC). Artworks are carefully encased in waterproof foil, bubble wrap, and rigid wood-panel armored boxes to ensure 100% zero-damage delivery.',
    category: 'Shipping & Delivery'
  },
  {
    id: 'faq-06',
    question: 'What happens if a painting status says "SOLD"?',
    answer: 'When a painting is marked "SOLD" with a red badge, that specific original artwork has been acquired by a collector. However, you can click "Request Similar Artwork" or submit a custom commission, and Vishal Kumar Baroliya will craft a new custom piece tailored to your taste!',
    category: 'General'
  },
  {
    id: 'faq-07',
    question: 'Are the paintings framed or unframed?',
    answer: 'Most paintings are available with premium Italian floating frames or solid wood gallery frames as specified in the painting description. You can also request unframed artworks shipped safely in heavy-duty mailing tubes if you prefer custom framing locally.',
    category: 'Framing & Authenticity'
  }
];
