import { Review } from '../types';

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-01',
    customerName: 'Ananya Sharma',
    location: 'Mumbai, Maharashtra',
    artworkName: 'Custom Couple Anniversary Portrait',
    rating: 5,
    comment: 'Vishal sir created a charcoal portrait for my parents 30th anniversary. The level of detail in their eyes and smiles brought tears of joy to our family. Truly international gallery quality craftsmanship!',
    date: '2025-11-14',
    verified: true,
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'
  },
  {
    id: 'rev-02',
    customerName: 'Rajesh & Meera Singhania',
    location: 'Jaipur, Rajasthan',
    artworkName: 'Golden Hour Aravali Mountains Landscape',
    rating: 5,
    comment: 'The oil painting arrived in a heavy wooden protective box with a signed Certificate of Authenticity. It is now the focal centerpiece of our main living room. The gold frame accent is exquisite.',
    date: '2025-12-02',
    verified: true,
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80'
  },
  {
    id: 'rev-03',
    customerName: 'Vikramaditya Roy',
    location: 'Bengaluru, Karnataka',
    artworkName: 'Eternal Gaze Charcoal Portrait',
    rating: 5,
    comment: 'The depth of shadows in Vishal’s charcoal work is unreal. Ordering via WhatsApp was seamless, and UPI payment was super smooth. Delivered safely in 4 days!',
    date: '2026-01-10',
    verified: true,
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80'
  },
  {
    id: 'rev-04',
    customerName: 'Priya Nair',
    location: 'Delhi NCR',
    artworkName: 'Serene Lotus Blossom in Water',
    rating: 5,
    comment: 'The delicate translucent wash of colors in watercolor is so soothing. I love that each piece from Baru Sketch Gallery is 100% original and handmade.',
    date: '2026-02-01',
    verified: true,
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=200&q=80'
  }
];
