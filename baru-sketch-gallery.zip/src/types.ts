export type MediumType =
  | 'Pencil'
  | 'Charcoal'
  | 'Oil'
  | 'Acrylic'
  | 'Watercolor'
  | 'Graphite & Charcoal'
  | 'Mixed Media';

export type CategoryType =
  | 'Pencil Sketch'
  | 'Charcoal Sketch'
  | 'Portrait'
  | 'Acrylic Painting'
  | 'Oil Painting'
  | 'Watercolor'
  | 'Landscape'
  | 'Custom Artwork';

export type SurfaceType = 'Canvas' | 'Heavyweight Acid-Free Paper' | 'Wood Panel';
export type FrameType = 'Framed' | 'Unframed' | 'Custom Gold Frame Included';

export interface Painting {
  id: string;
  name: string;
  category: CategoryType;
  medium: MediumType;
  height: number;
  width: number;
  unit: 'inch' | 'cm';
  price: number; // in INR ₹
  status: 'Available' | 'Sold';
  surface: SurfaceType;
  frame: FrameType;
  year: number;
  shortDescription: string;
  description: string;
  imageUrl: string;
  featured?: boolean;
  bestSeller?: boolean;
  tags: string[];
}

export interface CustomCommissionRequest {
  id: string;
  name: string;
  phone: string;
  email: string;
  referenceImageUrl?: string;
  preferredSize: string;
  medium: string;
  description: string;
  budget: string;
  deliveryDate: string;
  status: 'Pending' | 'Contacted' | 'In Progress' | 'Completed';
  createdAt: string;
}

export interface Review {
  id: string;
  customerName: string;
  location: string;
  artworkName?: string;
  rating: number;
  comment: string;
  date: string;
  verified: boolean;
  avatarUrl?: string;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  readTime: string;
  imageUrl: string;
  category: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'General' | 'Custom Orders' | 'Shipping & Delivery' | 'Framing & Authenticity';
}
