import React from 'react';
import { Award, Palette, MapPin, CheckCircle2, Sparkles, HeartHandshake } from 'lucide-react';

export const AboutArtist: React.FC = () => {
  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 bg-[#111111] text-white relative overflow-hidden border-b border-[#c8a165]/20">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
        {/* Left Column: Artist Portrait & Studio Visuals */}
        <div className="relative space-y-4">
          <div className="relative overflow-hidden border border-[#c8a165]/30 shadow-md group">
            <img
              src="https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1200&q=80"
              alt="Artist Vishal Kumar Baroliya in Studio"
              className="w-full h-[450px] sm:h-[520px] object-cover object-top group-hover:scale-105 transition-transform duration-700"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#111111] via-transparent to-transparent"></div>

            {/* Location & Experience Badge */}
            <div className="absolute bottom-6 left-6 right-6 p-4 bg-[#111111]/90 border border-[#c8a165]/30 flex items-center justify-between">
              <div>
                <span className="text-[9px] text-[#c8a165] font-bold uppercase tracking-[0.2em] block">Lead Master Artist</span>
                <span className="font-serif text-lg italic text-white font-light">Vishal Kumar Baroliya</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-neutral-300 font-light">
                <MapPin className="w-4 h-4 text-[#c8a165]" />
                <span>Beawar, Rajasthan</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Narrative & Biography */}
        <div className="space-y-6">
          <span className="text-[#c8a165] text-xs font-semibold tracking-[0.3em] uppercase block">
            Master Artist & Founder
          </span>

          <h2 className="font-serif text-3xl sm:text-5xl font-light italic leading-tight">
            Meet <span className="text-[#c8a165] not-italic">Vishal Kumar Baroliya</span>
          </h2>

          <p className="text-neutral-300 text-sm leading-relaxed font-light">
            Founded by artist Vishal Kumar Baroliya, <span className="font-medium text-[#c8a165]">Baru Sketch Gallery</span> is a premium destination for exquisite handmade fine art. Operating out of Masuda Road, Beawar, Rajasthan, Vishal’s artwork seamlessly bridges traditional Indian heritage aesthetics with modern realistic hyper-realism.
          </p>

          <p className="text-neutral-300 text-sm leading-relaxed font-light">
            Whether rendering delicate human expressions in willow charcoal, intricate bridal turbans in graphite, or golden sunset valleys in rich oil pigments, every piece produced at Baru Sketch Gallery represents dozens of hours of painstaking manual precision.
          </p>

          {/* Core Philosophy Bullet Points */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div className="p-4 bg-[#161616] border border-[#c8a165]/20 flex items-start gap-3">
              <CheckCircle2 className="w-4 h-4 text-[#c8a165] shrink-0 mt-0.5" />
              <div>
                <span className="font-serif italic text-sm text-white block">100% Manual Craft</span>
                <span className="text-xs text-neutral-400 font-light">Zero prints or digital overlays — every stroke is drawn by hand.</span>
              </div>
            </div>

            <div className="p-4 bg-[#161616] border border-[#c8a165]/20 flex items-start gap-3">
              <Award className="w-4 h-4 text-[#c8a165] shrink-0 mt-0.5" />
              <div>
                <span className="font-serif italic text-sm text-white block">Archival Durability</span>
                <span className="text-xs text-neutral-400 font-light">Crafted on 300 GSM acid-free paper & linen canvas meant to last centuries.</span>
              </div>
            </div>
          </div>

          {/* Artist Signature & Contact Quote */}
          <div className="pt-4 border-t border-[#c8a165]/20 flex items-center justify-between">
            <div>
              <span className="block text-[10px] text-[#c8a165] font-bold uppercase tracking-[0.2em]">Handcrafted In</span>
              <span className="font-serif italic text-sm text-neutral-200">Beawar, Rajasthan – India</span>
            </div>

            <div className="text-right">
              <span className="font-serif italic text-2xl text-[#c8a165] block">V. K. Baroliya</span>
              <span className="text-[9px] text-neutral-400 uppercase tracking-widest">Artist Signature</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
