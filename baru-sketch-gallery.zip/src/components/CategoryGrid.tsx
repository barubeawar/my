import React from 'react';
import { CategoryType } from '../types';
import { Sparkles, Palette } from 'lucide-react';

interface CategoryGridProps {
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
}

export const CATEGORIES: { name: CategoryType; count: string; imageUrl: string; description: string }[] = [
  {
    name: 'Pencil Sketch',
    count: '15+ Artworks',
    imageUrl: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=600&q=80',
    description: 'Fine graphite studies with smooth gradients and precise detail.'
  },
  {
    name: 'Charcoal Sketch',
    count: '20+ Artworks',
    imageUrl: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=600&q=80',
    description: 'Deep contrast willow charcoal portraits with rich emotional depth.'
  },
  {
    name: 'Portrait',
    count: '35+ Artworks',
    imageUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
    description: 'Realistic human and heritage portraits crafted from life & photos.'
  },
  {
    name: 'Acrylic Painting',
    count: '18+ Artworks',
    imageUrl: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=600&q=80',
    description: 'Vibrant heavy body acrylics with gold leaf and metallic highlights.'
  },
  {
    name: 'Oil Painting',
    count: '25+ Artworks',
    imageUrl: 'https://images.unsplash.com/photo-1501472312651-726afe119ff1?auto=format&fit=crop&w=600&q=80',
    description: 'Classical impasto oil canvases with luminescent light transitions.'
  },
  {
    name: 'Watercolor',
    count: '12+ Artworks',
    imageUrl: 'https://images.unsplash.com/photo-1582562124811-c09040d0a901?auto=format&fit=crop&w=600&q=80',
    description: 'Ethereal translucent washes on 100% cotton cold-press archival paper.'
  },
  {
    name: 'Landscape',
    count: '16+ Artworks',
    imageUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=600&q=80',
    description: 'Serene mountain vistas, sunset valleys, and Rajasthan heritage.'
  },
  {
    name: 'Custom Artwork',
    count: 'Commission',
    imageUrl: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=600&q=80',
    description: 'Personalized portraits, wedding gifts, and custom canvas commissions.'
  }
];

export const CategoryGrid: React.FC<CategoryGridProps> = ({ selectedCategory, onSelectCategory }) => {
  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-[#f8f5ef] dark:bg-[#111111] border-b border-[#c8a165]/20">
      <div className="max-w-7xl mx-auto space-y-10">
        <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-4">
          <div>
            <span className="text-[#c8a165] text-xs font-semibold tracking-[0.3em] uppercase block mb-1">
              Curated Mediums & Styles
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-light italic text-neutral-900 dark:text-neutral-100">
              Browse Art By Category
            </h2>
          </div>

          <button
            onClick={() => onSelectCategory('All')}
            className="text-xs uppercase tracking-widest font-bold text-[#c8a165] hover:underline flex items-center gap-1"
          >
            <span>View All Categories</span>
            <span>→</span>
          </button>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat.name;
            return (
              <div
                key={cat.name}
                onClick={() => onSelectCategory(cat.name)}
                className={`group relative overflow-hidden aspect-[4/5] cursor-pointer shadow-xs hover:shadow-md transition-all duration-300 border ${
                  isSelected
                    ? 'border-[#c8a165] ring-1 ring-[#c8a165]'
                    : 'border-[#111111]/10 dark:border-[#c8a165]/20'
                }`}
              >
                {/* Background Artwork Image */}
                <img
                  src={cat.imageUrl}
                  alt={cat.name}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
                  referrerPolicy="no-referrer"
                />

                {/* Dark Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#111111] via-[#111111]/40 to-transparent"></div>

                {/* Text Content */}
                <div className="absolute inset-0 p-4 flex flex-col justify-end text-white space-y-1">
                  <span className="text-[9px] uppercase font-bold tracking-[0.2em] text-[#c8a165]">
                    {cat.count}
                  </span>
                  <h3 className="font-serif text-lg sm:text-xl italic font-light group-hover:text-[#c8a165] transition-colors">
                    {cat.name}
                  </h3>
                  <p className="text-[10px] text-neutral-300 line-clamp-2 font-light hidden sm:block">
                    {cat.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
