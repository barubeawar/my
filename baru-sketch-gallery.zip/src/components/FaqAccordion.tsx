import React, { useState } from 'react';
import { FAQS } from '../data/faqs';
import { ChevronDown, Search, HelpCircle } from 'lucide-react';

export const FaqAccordion: React.FC = () => {
  const [openId, setOpenId] = useState<string | null>('faq-01');
  const [activeTab, setActiveTab] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');

  const categories = ['All', 'General', 'Custom Orders', 'Shipping & Delivery', 'Framing & Authenticity'];

  const filteredFaqs = FAQS.filter((faq) => {
    const matchesTab = activeTab === 'All' || faq.category === activeTab;
    const matchesSearch =
      faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesTab && matchesSearch;
  });

  return (
    <section id="faq" className="py-20 px-4 sm:px-6 lg:px-8 bg-[#f8f5ef] dark:bg-[#111111] transition-colors border-b border-[#c8a165]/20">
      <div className="max-w-4xl mx-auto space-y-10">
        <div className="text-center space-y-2">
          <span className="text-[#c8a165] text-xs font-semibold tracking-[0.3em] uppercase block">
            Got Questions?
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-light italic text-neutral-900 dark:text-neutral-100">
            Frequently Asked Questions
          </h2>
          <p className="text-xs text-neutral-600 dark:text-neutral-400 font-light">
            Everything you need to know about custom portrait orders, shipping, framing, and payment options.
          </p>
        </div>

        {/* Search Bar */}
        <div className="relative max-w-lg mx-auto">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#c8a165]" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search questions (e.g. framing, shipping, custom)..."
            className="w-full pl-10 pr-4 py-3 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-white dark:bg-[#161616] text-neutral-900 dark:text-neutral-100 text-xs focus:border-[#c8a165] focus:outline-none"
          />
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveTab(cat)}
              className={`px-4 py-2 border text-[10px] tracking-[0.15em] uppercase font-semibold transition-all cursor-pointer ${
                activeTab === cat
                  ? 'bg-[#111111] dark:bg-[#c8a165] text-white dark:text-[#111111] border-[#111111] dark:border-[#c8a165]'
                  : 'bg-white dark:bg-[#161616] border-[#111111]/15 dark:border-[#c8a165]/20 text-neutral-700 dark:text-neutral-300 hover:border-[#c8a165]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* FAQ List */}
        <div className="space-y-3">
          {filteredFaqs.map((faq) => {
            const isOpen = openId === faq.id;
            return (
              <div
                key={faq.id}
                className="bg-white dark:bg-[#161616] border border-[#111111]/10 dark:border-[#c8a165]/20 overflow-hidden shadow-xs transition-all"
              >
                <button
                  onClick={() => setOpenId(isOpen ? null : faq.id)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 font-serif font-light italic text-base sm:text-lg text-neutral-900 dark:text-neutral-100 hover:text-[#c8a165] transition-colors cursor-pointer"
                >
                  <span>{faq.question}</span>
                  <ChevronDown className={`w-4 h-4 shrink-0 text-[#c8a165] transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 pt-0 text-xs text-neutral-600 dark:text-neutral-400 font-light leading-relaxed border-t border-[#111111]/10 dark:border-[#c8a165]/20 pt-4 mt-1">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
