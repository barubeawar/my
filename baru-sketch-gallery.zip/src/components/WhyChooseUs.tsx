import React from 'react';
import { ShieldCheck, Award, MessageCircle, PackageCheck, Truck, Sparkles } from 'lucide-react';

export const WhyChooseUs: React.FC = () => {
  const features = [
    {
      icon: ShieldCheck,
      title: '100% Original Handmade',
      description: 'Every sketch and painting is manually created by artist Vishal Kumar Baroliya without any digital prints or machine aid.'
    },
    {
      icon: Award,
      title: 'Certificate of Authenticity',
      description: 'Physical hand-signed & stamped Certificate of Authenticity included with every single purchase.'
    },
    {
      icon: MessageCircle,
      title: 'Direct Artist Communication',
      description: 'Speak directly with artist Vishal via WhatsApp or call for customized sizing, color adjustments, and portrait progress updates.'
    },
    {
      icon: PackageCheck,
      title: 'Armored Wooden Box Packaging',
      description: 'Encased in moisture-proof foil, shockproof bubble wrap, and rigid wood-panel armored boxes for zero-damage transit.'
    },
    {
      icon: Truck,
      title: 'Free Express Shipping Across India',
      description: 'Insured express courier delivery (Bluedart / DTDC) dispatched straight to your doorstep with live tracking.'
    },
    {
      icon: Sparkles,
      title: 'Custom Framing & Sizing',
      description: 'Choose between raw canvas rolls, archival acid-free mounted papers, or luxury gold floating frames.'
    }
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#f8f5ef] dark:bg-[#111111] transition-colors border-b border-[#c8a165]/20">
      <div className="max-w-7xl mx-auto space-y-12">
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="text-[#c8a165] text-xs font-semibold tracking-[0.3em] uppercase block">
            The Baru Quality Standard
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-light italic text-neutral-900 dark:text-neutral-100">
            Why Choose Baru Sketch Gallery?
          </h2>
          <p className="text-xs text-neutral-600 dark:text-neutral-400 font-light">
            We deliver international gallery elegance, direct artist trust, and lifelong archival durability.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="bg-white dark:bg-[#161616] p-6 border border-[#111111]/10 dark:border-[#c8a165]/20 shadow-xs hover:shadow-md transition-all space-y-3"
              >
                <div className="w-10 h-10 bg-[#f8f5ef] dark:bg-[#111111] text-[#c8a165] border border-[#c8a165]/30 flex items-center justify-center">
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="font-serif font-light italic text-lg text-neutral-900 dark:text-neutral-100">
                  {item.title}
                </h3>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed font-light">
                  {item.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
