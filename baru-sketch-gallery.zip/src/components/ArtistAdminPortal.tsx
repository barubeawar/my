import React, { useState } from 'react';
import { Painting, CustomCommissionRequest } from '../types';
import {
  X,
  Palette,
  CheckCircle2,
  AlertCircle,
  Edit2,
  Plus,
  Save,
  Trash2,
  Lock,
  Unlock,
  Eye,
  MessageSquare,
  Sparkles,
  DollarSign
} from 'lucide-react';

interface ArtistAdminPortalProps {
  paintings: Painting[];
  onUpdatePainting: (updated: Painting) => void;
  onAddPainting: (newPainting: Painting) => void;
  onDeletePainting: (id: string) => void;
  commissionRequests: CustomCommissionRequest[];
  onClose: () => void;
  currency: 'INR' | 'USD';
}

export const ArtistAdminPortal: React.FC<ArtistAdminPortalProps> = ({
  paintings,
  onUpdatePainting,
  onAddPainting,
  onDeletePainting,
  commissionRequests,
  onClose,
  currency,
}) => {
  const [authenticated, setAuthenticated] = useState(true); // Default accessible
  const [passcode, setPasscode] = useState('');
  const [passcodeError, setPasscodeError] = useState('');
  const [activeTab, setActiveTab] = useState<'inventory' | 'add' | 'requests'>('inventory');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Painting | null>(null);

  // New Painting Form state
  const [newForm, setNewForm] = useState<Omit<Painting, 'id'>>({
    name: '',
    category: 'Pencil Sketch',
    medium: 'Pencil',
    height: 18,
    width: 24,
    unit: 'inch',
    price: 12000,
    status: 'Available',
    surface: 'Heavyweight Acid-Free Paper',
    frame: 'Framed',
    year: 2026,
    shortDescription: '',
    description: '',
    imageUrl: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=1200&q=80',
    tags: ['Handmade', 'Original'],
  });

  const handleToggleStatus = (p: Painting) => {
    const newStatus = p.status === 'Available' ? 'Sold' : 'Available';
    onUpdatePainting({ ...p, status: newStatus });
  };

  const startEditing = (p: Painting) => {
    setEditingId(p.id);
    setEditForm({ ...p });
  };

  const saveEditing = () => {
    if (editForm) {
      onUpdatePainting(editForm);
      setEditingId(null);
      setEditForm(null);
    }
  };

  const handleAddNew = (e: React.FormEvent) => {
    e.preventDefault();
    const newId = `art-${Date.now().toString().slice(-4)}`;
    onAddPainting({ ...newForm, id: newId });
    setActiveTab('inventory');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm animate-fadeIn overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-white dark:bg-[#161616] shadow-2xl overflow-hidden border border-[#111111]/20 dark:border-[#c8a165]/30 p-6 sm:p-8 my-auto max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#111111]/10 dark:border-[#c8a165]/20 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 border border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-[#c8a165]">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif text-xl sm:text-2xl font-light italic text-neutral-900 dark:text-neutral-100">
                Artist Admin Control Portal
              </h3>
              <p className="text-xs text-neutral-500 font-light">
                Manage Inventory Status (Available / Sold), Prices, Sizes & Custom Orders — Artist Vishal Kumar Baroliya
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 border border-[#c8a165]/20 bg-[#f8f5ef] dark:bg-[#111111] text-[#c8a165] hover:bg-[#c8a165] hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 pt-4 pb-2 border-b border-[#111111]/10 dark:border-[#c8a165]/20 shrink-0">
          <button
            onClick={() => setActiveTab('inventory')}
            className={`px-4 py-2 text-[10px] uppercase font-bold tracking-widest transition-colors cursor-pointer ${
              activeTab === 'inventory'
                ? 'bg-[#c8a165] text-white'
                : 'bg-[#f8f5ef] dark:bg-[#111111] border border-[#111111]/10 dark:border-[#c8a165]/20 text-neutral-700 dark:text-neutral-300'
            }`}
          >
            Manage Inventory ({paintings.length})
          </button>

          <button
            onClick={() => setActiveTab('add')}
            className={`px-4 py-2 text-[10px] uppercase font-bold tracking-widest transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'add'
                ? 'bg-[#c8a165] text-white'
                : 'bg-[#f8f5ef] dark:bg-[#111111] border border-[#111111]/10 dark:border-[#c8a165]/20 text-neutral-700 dark:text-neutral-300'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add New Painting</span>
          </button>

          <button
            onClick={() => setActiveTab('requests')}
            className={`px-4 py-2 text-[10px] uppercase font-bold tracking-widest transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'requests'
                ? 'bg-[#c8a165] text-white'
                : 'bg-[#f8f5ef] dark:bg-[#111111] border border-[#111111]/10 dark:border-[#c8a165]/20 text-neutral-700 dark:text-neutral-300'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Commission Requests ({commissionRequests.length})</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="overflow-y-auto pt-4 space-y-4 flex-grow">
          {activeTab === 'inventory' && (
            <div className="space-y-4">
              <div className="text-xs text-neutral-500 bg-[#f8f5ef] dark:bg-[#111111] p-3 border border-[#c8a165]/30 font-light">
                💡 <span className="font-semibold text-neutral-800 dark:text-neutral-200">Quick Artist Control:</span> Click the <span className="text-emerald-600 font-bold">AVAILABLE</span> or <span className="text-rose-600 font-bold">SOLD</span> button below to immediately change an artwork's status across the entire gallery store.
              </div>

              <div className="divide-y divide-[#111111]/10 dark:divide-[#c8a165]/20">
                {paintings.map((p) => {
                  const isEditing = editingId === p.id;
                  return (
                    <div key={p.id} className="py-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                      {/* Left thumbnail & basic info */}
                      <div className="flex items-center gap-4 w-full md:w-auto">
                        <img
                          src={p.imageUrl}
                          alt={p.name}
                          className="w-16 h-16 object-cover border border-[#c8a165]/20 shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <div className="space-y-1">
                          {isEditing ? (
                            <input
                              type="text"
                              value={editForm?.name || ''}
                              onChange={(e) => setEditForm({ ...editForm!, name: e.target.value })}
                              className="px-2 py-1 border border-[#c8a165]/30 text-xs font-serif italic"
                            />
                          ) : (
                            <h4 className="font-serif font-light italic text-base text-neutral-900 dark:text-neutral-100">
                              {p.name}
                            </h4>
                          )}

                          <div className="flex items-center gap-2 text-xs text-neutral-500 font-light">
                            <span>{p.category}</span>
                            <span>•</span>
                            <span>
                              {p.height}×{p.width} {p.unit}
                            </span>
                            <span>•</span>
                            <span className="font-serif italic text-[#c8a165]">
                              ₹{p.price.toLocaleString('en-IN')}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Controls Row */}
                      <div className="flex items-center gap-3 w-full md:w-auto justify-end">
                        {/* Status Toggle Switch */}
                        <button
                          onClick={() => handleToggleStatus(p)}
                          className={`px-3.5 py-1 text-[10px] font-bold tracking-widest uppercase transition-transform active:scale-95 flex items-center gap-1.5 cursor-pointer ${
                            p.status === 'Available'
                              ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                              : 'bg-rose-600 hover:bg-rose-700 text-white'
                          }`}
                          title="Click to toggle Available <-> Sold"
                        >
                          {p.status === 'Available' ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>AVAILABLE</span>
                            </>
                          ) : (
                            <>
                              <AlertCircle className="w-3.5 h-3.5" />
                              <span>SOLD</span>
                            </>
                          )}
                        </button>

                        {/* Edit Button */}
                        {isEditing ? (
                          <button
                            onClick={saveEditing}
                            className="p-2 bg-emerald-600 text-white text-xs font-semibold flex items-center gap-1 cursor-pointer"
                          >
                            <Save className="w-3.5 h-3.5" />
                          </button>
                        ) : (
                          <button
                            onClick={() => startEditing(p)}
                            className="p-2 border border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-[#c8a165] hover:bg-[#c8a165] hover:text-white transition-colors cursor-pointer"
                            title="Edit Details"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {/* Delete Button */}
                        <button
                          onClick={() => onDeletePainting(p.id)}
                          className="p-2 bg-rose-100 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 hover:bg-rose-200 transition-colors cursor-pointer"
                          title="Delete Painting"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {activeTab === 'add' && (
            <form onSubmit={handleAddNew} className="space-y-4 max-w-2xl mx-auto">
              <h4 className="font-serif text-lg font-light italic">Add New Masterpiece Artwork</h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase font-bold tracking-wider mb-1">Painting Title *</label>
                  <input
                    type="text"
                    required
                    value={newForm.name}
                    onChange={(e) => setNewForm({ ...newForm, name: e.target.value })}
                    placeholder="e.g. Moonlight Charcoal Sketch"
                    className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-xs focus:border-[#c8a165] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold tracking-wider mb-1">Category *</label>
                  <select
                    value={newForm.category}
                    onChange={(e) => setNewForm({ ...newForm, category: e.target.value as any })}
                    className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-xs focus:border-[#c8a165] focus:outline-none"
                  >
                    <option value="Pencil Sketch">Pencil Sketch</option>
                    <option value="Charcoal Sketch">Charcoal Sketch</option>
                    <option value="Portrait">Portrait</option>
                    <option value="Acrylic Painting">Acrylic Painting</option>
                    <option value="Oil Painting">Oil Painting</option>
                    <option value="Watercolor">Watercolor</option>
                    <option value="Landscape">Landscape</option>
                    <option value="Custom Artwork">Custom Artwork</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold tracking-wider mb-1">Price (INR ₹) *</label>
                  <input
                    type="number"
                    required
                    value={newForm.price}
                    onChange={(e) => setNewForm({ ...newForm, price: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-xs focus:border-[#c8a165] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold tracking-wider mb-1">Dimensions (Height × Width) *</label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      required
                      value={newForm.height}
                      onChange={(e) => setNewForm({ ...newForm, height: Number(e.target.value) })}
                      placeholder="H"
                      className="w-1/2 px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-xs focus:border-[#c8a165] focus:outline-none"
                    />
                    <input
                      type="number"
                      required
                      value={newForm.width}
                      onChange={(e) => setNewForm({ ...newForm, width: Number(e.target.value) })}
                      placeholder="W"
                      className="w-1/2 px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-xs focus:border-[#c8a165] focus:outline-none"
                    />
                  </div>
                </div>

                <div className="col-span-2">
                  <label className="block text-[10px] uppercase font-bold tracking-wider mb-1">Image URL *</label>
                  <input
                    type="url"
                    required
                    value={newForm.imageUrl}
                    onChange={(e) => setNewForm({ ...newForm, imageUrl: e.target.value })}
                    className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-xs focus:border-[#c8a165] focus:outline-none"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-[10px] uppercase font-bold tracking-wider mb-1">Description</label>
                  <textarea
                    rows={3}
                    value={newForm.description}
                    onChange={(e) => setNewForm({ ...newForm, description: e.target.value, shortDescription: e.target.value.slice(0, 80) })}
                    className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-xs focus:border-[#c8a165] focus:outline-none"
                  ></textarea>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#c8a165] text-white text-[10px] tracking-[0.2em] uppercase font-bold hover:bg-[#b08b52] transition-colors cursor-pointer"
              >
                Publish Artwork to Gallery
              </button>
            </form>
          )}

          {activeTab === 'requests' && (
            <div className="space-y-4">
              {commissionRequests.length === 0 ? (
                <p className="text-center text-xs text-neutral-500 py-8 font-light">
                  No pending custom portrait requests yet. Incoming commission inquiries will appear here!
                </p>
              ) : (
                <div className="space-y-3">
                  {commissionRequests.map((req) => (
                    <div key={req.id} className="p-4 bg-[#f8f5ef] dark:bg-[#111111] border border-[#111111]/10 dark:border-[#c8a165]/20 space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-[#c8a165]">{req.name}</span>
                        <span className="text-neutral-400 font-light">{req.createdAt}</span>
                      </div>
                      <div className="text-xs space-y-1 text-neutral-600 dark:text-neutral-400 font-light">
                        <p>Phone: <span className="font-semibold">{req.phone}</span> | Email: {req.email}</p>
                        <p>Medium: {req.medium} | Size: {req.preferredSize} | Budget: {req.budget}</p>
                        <p className="italic font-serif">"{req.description}"</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
