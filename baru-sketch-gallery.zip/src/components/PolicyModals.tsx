import React from 'react';
import { X, ShieldCheck, Truck, RotateCcw, FileText } from 'lucide-react';

interface PolicyModalProps {
  type: 'shipping' | 'privacy' | 'terms' | 'return' | null;
  onClose: () => void;
}

export const PolicyModal: React.FC<PolicyModalProps> = ({ type, onClose }) => {
  if (!type) return null;

  const titles = {
    shipping: 'Shipping & Armored Delivery Policy',
    privacy: 'Privacy & Collector Data Policy',
    terms: 'Terms & Conditions of Sale',
    return: 'Return, Refund & Satisfaction Guarantee',
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white dark:bg-[#161616] p-6 sm:p-8 space-y-4 border border-[#111111]/20 dark:border-[#c8a165]/30 shadow-2xl my-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 border border-[#c8a165]/20 bg-[#f8f5ef] dark:bg-[#111111] text-[#c8a165] hover:bg-[#c8a165] hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        <h3 className="font-serif text-2xl font-light italic">{titles[type]}</h3>

        <div className="text-xs text-neutral-700 dark:text-neutral-300 leading-relaxed space-y-3 font-light max-h-[60vh] overflow-y-auto pr-2">
          {type === 'shipping' && (
            <>
              <p>
                <strong className="font-semibold text-[#c8a165]">Express Nationwide Delivery:</strong> All original paintings and custom portrait commissions from Baru Sketch Gallery are shipped across India via express insured couriers (Bluedart, DTDC, Expressbees). Standard delivery timelines range between 4 to 7 business days.
              </p>
              <p>
                <strong className="font-semibold text-[#c8a165]">Zero-Damage Armored Packaging:</strong> Every painting is wrapped in waterproof foil, multi-layer high-density bubble cushioning, and custom wooden box paneling to prevent moisture, dust, or impact during transit.
              </p>
              <p>
                <strong className="font-semibold text-[#c8a165]">Tracking & Dispatch:</strong> Upon dispatch from our Beawar studio, tracking details are sent via WhatsApp and Email.
              </p>
            </>
          )}

          {type === 'privacy' && (
            <>
              <p>
                <strong className="font-semibold text-[#c8a165]">Data Protection:</strong> Baru Sketch Gallery respects collector privacy. Your contact information, reference portrait photographs, and delivery address are strictly utilized for processing your order and shipping.
              </p>
              <p>
                <strong className="font-semibold text-[#c8a165]">No Third-Party Sharing:</strong> We never sell, rent, or distribute your private photos or personal data to third parties.
              </p>
            </>
          )}

          {type === 'terms' && (
            <>
              <p>
                <strong className="font-semibold text-[#c8a165]">Authenticity Guarantee:</strong> All original artworks sold on this website are 100% hand-drawn or hand-painted by master artist Vishal Kumar Baroliya and accompany an official Certificate of Authenticity.
              </p>
              <p>
                <strong className="font-semibold text-[#c8a165]">Custom Commissions:</strong> Custom portrait orders require a reference photo approval before final varnish and dispatch.
              </p>
            </>
          )}

          {type === 'return' && (
            <>
              <p>
                <strong className="font-semibold text-[#c8a165]">100% Satisfaction & Replacement Guarantee:</strong> In the rare event an artwork arrives physically damaged during transit, please record an unboxing video and notify us on WhatsApp (+91 8000917547) within 24 hours for a full replacement or artist repair.
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
