import React from 'react';
import { ArrowRight, Sparkles, ShieldCheck, Award, Truck, Palette } from 'lucide-react';

interface HeroProps {
  onExploreGallery: () => void;
  onOrderCustom: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreGallery, onOrderCustom }) => {
  return (
    <section className="relative min-h-[85vh] lg:min-h-[90vh] flex items-center justify-center pt-28 pb-16 px-4 sm:px-6 lg:px-12 overflow-hidden bg-[#111111] text-white border-b border-[#c8a165]/20">
      {/* Background Image with Gradient Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=2000&q=85"
          alt="Baru Sketch Gallery Masterpiece Artwork"
          className="w-full h-full object-cover object-center opacity-30 filter brightness-90 transition-transform duration-1000 scale-105 hover:scale-100"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#111111] via-[#111111]/70 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-[#111111]/90 via-transparent to-[#111111]/90"></div>
      </div>

      {/* Hero Content Container */}
      <div className="relative z-10 max-w-4xl mx-auto text-center space-y-6 py-8">
        {/* Subtle Artist Eyebrow Tag */}
        <span className="text-[#c8a165] text-xs font-semibold tracking-[0.3em] uppercase block">
          Featured Fine Art & Custom Portraits
        </span>

        {/* Main Headline */}
        <h1 className="font-serif text-4xl sm:text-6xl lg:text-7xl font-light italic text-white leading-tight">
          Transforming Imagination Into <span className="text-[#c8a165] not-italic">Timeless Art</span>
        </h1>

        {/* Subheading */}
        <p className="max-w-xl mx-auto text-sm sm:text-base text-neutral-300 font-light leading-relaxed">
          Experience the depth of handmade charcoal portraits, pencil sketches, and oil canvas paintings created for fine art collectors by <span className="font-medium text-[#c8a165]">Vishal Kumar Baroliya</span>.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
          <button
            onClick={onExploreGallery}
            className="w-full sm:w-auto px-8 py-3.5 bg-[#c8a165] text-white text-[10px] tracking-[0.2em] uppercase font-bold hover:bg-[#b08b52] transition-colors shadow-md flex items-center justify-center gap-2 group cursor-pointer"
          >
            <span>View Gallery</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            onClick={onOrderCustom}
            className="w-full sm:w-auto px-8 py-3.5 bg-white/10 backdrop-blur-md border border-white/30 text-white text-[10px] tracking-[0.2em] uppercase font-bold hover:bg-white/20 transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <Palette className="w-4 h-4 text-[#c8a165]" />
            <span>Custom Artwork</span>
          </button>
        </div>

        {/* Trust Stats & Guarantees */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-12 border-t border-[#c8a165]/20 max-w-3xl mx-auto text-left sm:text-center">
          <div className="flex flex-col sm:items-center p-3 border border-[#c8a165]/20 bg-[#111111]/60 backdrop-blur-xs">
            <ShieldCheck className="w-5 h-5 text-[#c8a165] mb-1" />
            <span className="text-[9px] text-[#c8a165] uppercase tracking-[0.2em] font-bold">100% Original</span>
            <span className="text-xs font-light text-neutral-200">Handmade Guarantee</span>
          </div>

          <div className="flex flex-col sm:items-center p-3 border border-[#c8a165]/20 bg-[#111111]/60 backdrop-blur-xs">
            <Award className="w-5 h-5 text-[#c8a165] mb-1" />
            <span className="text-[9px] text-[#c8a165] uppercase tracking-[0.2em] font-bold">Certificate</span>
            <span className="text-xs font-light text-neutral-200">Of Authenticity</span>
          </div>

          <div className="flex flex-col sm:items-center p-3 border border-[#c8a165]/20 bg-[#111111]/60 backdrop-blur-xs">
            <Truck className="w-5 h-5 text-[#c8a165] mb-1" />
            <span className="text-[9px] text-[#c8a165] uppercase tracking-[0.2em] font-bold">Express Shipping</span>
            <span className="text-xs font-light text-neutral-200">Armored Wooden Box</span>
          </div>

          <div className="flex flex-col sm:items-center p-3 border border-[#c8a165]/20 bg-[#111111]/60 backdrop-blur-xs">
            <Sparkles className="w-5 h-5 text-[#c8a165] mb-1" />
            <span className="text-[9px] text-[#c8a165] uppercase tracking-[0.2em] font-bold">Direct Artist</span>
            <span className="text-xs font-light text-neutral-200">Custom Commission</span>
          </div>
        </div>
      </div>
    </section>
  );
};
