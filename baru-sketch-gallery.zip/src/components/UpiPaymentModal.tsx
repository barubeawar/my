import React, { useState } from 'react';
import { Painting } from '../types';
import { X, QrCode, Check, Copy, MessageCircle, ShieldCheck, Truck, ArrowRight, Smartphone } from 'lucide-react';

interface UpiPaymentModalProps {
  painting: Painting | null;
  onClose: () => void;
  currency: 'INR' | 'USD';
}

export const UpiPaymentModal: React.FC<UpiPaymentModalProps> = ({ painting, onClose, currency }) => {
  if (!painting) return null;

  const [copiedUpi, setCopiedUpi] = useState(false);
  const [buyerName, setBuyerName] = useState('');
  const [buyerPhone, setBuyerPhone] = useState('');
  const [shippingAddress, setShippingAddress] = useState('');
  const [step, setStep] = useState<'details' | 'qr'>('details');

  const upiId = '8000917547@ybl'; // Artist Vishal Kumar Baroliya's UPI ID

  const formatPrice = (priceInInr: number) => {
    if (currency === 'USD') {
      const usd = Math.round(priceInInr / 85);
      return `$${usd.toLocaleString()}`;
    }
    return `₹${priceInInr.toLocaleString('en-IN')}`;
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(upiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const handleProceedToPayment = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('qr');
  };

  const whatsappConfirmMessage = encodeURIComponent(
    `Hello Vishal Kumar Baroliya!\nI am ready to buy "${painting.name}" (Price: ₹${painting.price.toLocaleString('en-IN')}).\n\n` +
    `👤 Buyer Name: ${buyerName}\n` +
    `📞 Phone: ${buyerPhone}\n` +
    `📍 Shipping Address: ${shippingAddress}\n\n` +
    `Please confirm UPI / QR payment receipt and share dispatch tracking details.`
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white dark:bg-[#161616] rounded-3xl shadow-2xl overflow-hidden border border-neutral-200 dark:border-neutral-800 p-6 sm:p-8 my-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-amber-600 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center space-y-2 pb-4 border-b border-neutral-200 dark:border-neutral-800">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 text-xs font-semibold">
            <ShieldCheck className="w-4 h-4" />
            <span>Direct Artist Direct Purchase (Zero Gateway Fees)</span>
          </div>
          <h3 className="font-serif text-2xl font-bold text-neutral-900 dark:text-neutral-100">
            Secure Order & UPI Payment
          </h3>
          <p className="text-xs text-neutral-500">
            Purchasing: <span className="font-semibold text-neutral-800 dark:text-neutral-200">{painting.name}</span>
          </p>
        </div>

        {step === 'details' ? (
          <form onSubmit={handleProceedToPayment} className="space-y-4 pt-4">
            <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/40 flex items-center justify-between text-xs sm:text-sm font-semibold">
              <span className="text-neutral-700 dark:text-neutral-300">Total Artwork Price:</span>
              <span className="text-lg font-serif font-bold text-amber-900 dark:text-amber-300">
                {formatPrice(painting.price)}
              </span>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                Your Full Name *
              </label>
              <input
                type="text"
                required
                value={buyerName}
                onChange={(e) => setBuyerName(e.target.value)}
                placeholder="e.g. Rahul Sharma"
                className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 text-sm focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                WhatsApp Phone Number *
              </label>
              <input
                type="tel"
                required
                value={buyerPhone}
                onChange={(e) => setBuyerPhone(e.target.value)}
                placeholder="e.g. 8000917547"
                className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 text-sm focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                Full Delivery Address *
              </label>
              <textarea
                rows={2}
                required
                value={shippingAddress}
                onChange={(e) => setShippingAddress(e.target.value)}
                placeholder="House no, Street, Landmark, City, State, Pincode"
                className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 text-sm focus:ring-2 focus:ring-amber-500 focus:outline-none"
              ></textarea>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-amber-800 hover:bg-amber-900 text-white font-semibold text-sm rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 active:scale-95"
            >
              <span>Proceed to UPI QR Code Payment</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        ) : (
          <div className="space-y-6 pt-4 text-center">
            {/* QR Code Container */}
            <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-md inline-block mx-auto">
              {/* Dynamic QR image generated via public QR API for seamless GPay/PhonePe scanning */}
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(
                  `upi://pay?pa=${upiId}&pn=Vishal%20Kumar%20Baroliya&am=${painting.price}&cu=INR&tn=${encodeURIComponent(
                    painting.name
                  )}`
                )}`}
                alt="UPI Payment QR Code"
                className="w-48 h-48 mx-auto object-contain"
              />
              <span className="block text-[11px] font-medium text-neutral-600 mt-2">
                Scan with Google Pay / PhonePe / Paytm / BHIM
              </span>
            </div>

            {/* UPI ID Copy Box */}
            <div className="p-3 rounded-xl bg-neutral-100 dark:bg-neutral-800 flex items-center justify-between text-xs">
              <div className="text-left">
                <span className="block text-[10px] text-neutral-400 font-semibold uppercase">UPI ID</span>
                <span className="font-mono font-bold text-neutral-900 dark:text-neutral-100">{upiId}</span>
              </div>
              <button
                onClick={copyToClipboard}
                className="px-3 py-1.5 bg-amber-800 text-white rounded-lg font-medium text-xs flex items-center gap-1"
              >
                {copiedUpi ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedUpi ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            {/* Direct WhatsApp Confirmation Button */}
            <a
              href={`https://wa.me/918000917547?text=${whatsappConfirmMessage}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3.5 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 active:scale-95"
            >
              <MessageCircle className="w-5 h-5" />
              <span>Confirm & Share Payment Receipt on WhatsApp</span>
            </a>

            <button
              onClick={() => setStep('details')}
              className="text-xs text-neutral-500 hover:underline block mx-auto"
            >
              ← Edit Shipping Details
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
