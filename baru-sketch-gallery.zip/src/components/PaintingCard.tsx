import React from 'react';
import { Painting } from '../types';
import { Heart, Eye, MessageCircle, ShoppingBag, ShieldCheck, CheckCircle2, AlertCircle } from 'lucide-react';

interface PaintingCardProps {
  painting: Painting;
  onSelect: (painting: Painting) => void;
  onToggleWishlist: (id: string) => void;
  isWishlisted: boolean;
  currency: 'INR' | 'USD';
  onBuyNow: (painting: Painting) => void;
}

export const PaintingCard: React.FC<PaintingCardProps> = ({
  painting,
  onSelect,
  onToggleWishlist,
  isWishlisted,
  currency,
  onBuyNow,
}) => {
  const formatPrice = (priceInInr: number) => {
    if (currency === 'USD') {
      const usd = Math.round(priceInInr / 85);
      return `$${usd.toLocaleString()}`;
    }
    return `₹${priceInInr.toLocaleString('en-IN')}`;
  };

  const isSold = painting.status === 'Sold';

  return (
    <div className="group relative bg-white dark:bg-[#161616] border border-[#111111]/10 dark:border-[#c8a165]/20 shadow-xs hover:shadow-md transition-all duration-300 flex flex-col h-full">
      {/* Image Container with Badges */}
      <div className="relative aspect-[3/4] overflow-hidden bg-[#f8f5ef] dark:bg-[#111111] cursor-pointer" onClick={() => onSelect(painting)}>
        <img
          src={painting.imageUrl}
          alt={painting.name}
          className={`w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out ${isSold ? 'grayscale opacity-75' : ''}`}
          loading="lazy"
          referrerPolicy="no-referrer"
        />

        {/* Top Badges */}
        <div className="absolute top-2 left-2 right-2 flex items-center justify-between pointer-events-none">
          {/* Status Badge */}
          {isSold ? (
            <span className="pointer-events-auto px-2 py-1 bg-red-600 text-white text-[8px] uppercase tracking-widest font-bold rounded-sm shadow-xs">
              Sold
            </span>
          ) : (
            <span className="pointer-events-auto px-2 py-1 bg-green-500 text-white text-[8px] uppercase tracking-widest font-bold rounded-sm shadow-xs">
              Available
            </span>
          )}

          {/* Wishlist Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleWishlist(painting.id);
            }}
            aria-label="Wishlist Artwork"
            className="pointer-events-auto p-1.5 rounded-full bg-white/90 dark:bg-[#111111]/90 text-neutral-800 dark:text-neutral-200 hover:text-rose-500 transition-colors shadow-xs"
          >
            <Heart className={`w-3.5 h-3.5 ${isWishlisted ? 'fill-rose-500 text-rose-500' : ''}`} />
          </button>
        </div>
      </div>

      {/* Card Content Details */}
      <div className="p-4 flex flex-col flex-grow justify-between space-y-3">
        <div className="space-y-1">
          <span className="text-[10px] text-[#c8a165] font-bold uppercase tracking-widest block">
            {painting.medium} • {painting.category}
          </span>

          <h3
            onClick={() => onSelect(painting)}
            className="font-serif text-lg italic text-neutral-900 dark:text-neutral-100 hover:text-[#c8a165] transition-colors line-clamp-1 cursor-pointer"
          >
            {painting.name}
          </h3>

          <p className="text-[10px] text-neutral-500 dark:text-neutral-400 font-light">
            {painting.height} × {painting.width} {painting.unit} • Handcrafted Artwork
          </p>
        </div>

        {/* Price & Primary Action */}
        <div className="pt-3 border-t border-[#111111]/10 dark:border-[#c8a165]/20 flex items-center justify-between gap-2">
          <div>
            <span className={`text-sm font-bold font-serif ${isSold ? 'line-through text-neutral-400' : 'text-neutral-900 dark:text-neutral-100'}`}>
              {formatPrice(painting.price)}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onSelect(painting)}
              className="px-3 py-1.5 border border-[#111111] dark:border-white/30 text-[9px] uppercase tracking-widest font-bold hover:bg-[#111111] hover:text-white transition-colors"
            >
              Details
            </button>

            {!isSold && (
              <button
                onClick={() => onBuyNow(painting)}
                className="px-3.5 py-1.5 bg-[#c8a165] text-white text-[9px] uppercase tracking-widest font-bold hover:bg-[#b08b52] transition-colors shadow-xs"
              >
                Buy Now
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
