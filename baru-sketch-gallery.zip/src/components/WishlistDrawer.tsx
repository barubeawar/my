import React from 'react';
import { Painting } from '../types';
import { X, Heart, Trash2, ShoppingBag, Eye } from 'lucide-react';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  wishlistIds: string[];
  paintings: Painting[];
  onRemoveFromWishlist: (id: string) => void;
  onSelectPainting: (p: Painting) => void;
  onBuyNow: (p: Painting) => void;
  currency: 'INR' | 'USD';
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  wishlistIds,
  paintings,
  onRemoveFromWishlist,
  onSelectPainting,
  onBuyNow,
  currency,
}) => {
  if (!isOpen) return null;

  const wishlistedPaintings = paintings.filter((p) => wishlistIds.includes(p.id));

  const formatPrice = (priceInInr: number) => {
    if (currency === 'USD') {
      const usd = Math.round(priceInInr / 85);
      return `$${usd.toLocaleString()}`;
    }
    return `₹${priceInInr.toLocaleString('en-IN')}`;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white dark:bg-[#161616] shadow-2xl flex flex-col border-l border-[#111111]/20 dark:border-[#c8a165]/30">
          {/* Header */}
          <div className="p-5 border-b border-[#111111]/10 dark:border-[#c8a165]/20 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Heart className="w-4 h-4 text-[#c8a165] fill-[#c8a165]" />
              <h3 className="font-serif font-light italic text-base">Your Saved Artworks ({wishlistedPaintings.length})</h3>
            </div>
            <button onClick={onClose} className="p-2 border border-[#c8a165]/20 bg-[#f8f5ef] dark:bg-[#111111] text-[#c8a165] hover:bg-[#c8a165] hover:text-white transition-colors cursor-pointer">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Items List */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {wishlistedPaintings.length === 0 ? (
              <div className="text-center py-16 space-y-3">
                <Heart className="w-10 h-10 text-neutral-300 mx-auto stroke-1" />
                <p className="text-xs text-neutral-500 font-light">Your wishlist is empty.</p>
                <p className="text-[10px] text-neutral-400 font-light">Save your favorite paintings while browsing the gallery!</p>
              </div>
            ) : (
              wishlistedPaintings.map((p) => (
                <div key={p.id} className="flex gap-4 p-3 bg-[#f8f5ef] dark:bg-[#111111] border border-[#111111]/10 dark:border-[#c8a165]/20 relative">
                  <img
                    src={p.imageUrl}
                    alt={p.name}
                    className="w-20 h-20 object-cover border border-[#c8a165]/20 cursor-pointer"
                    onClick={() => {
                      onClose();
                      onSelectPainting(p);
                    }}
                    referrerPolicy="no-referrer"
                  />

                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <h4
                        onClick={() => {
                          onClose();
                          onSelectPainting(p);
                        }}
                        className="font-serif font-light italic text-sm hover:text-[#c8a165] cursor-pointer line-clamp-1"
                      >
                        {p.name}
                      </h4>
                      <p className="text-[10px] text-neutral-500 font-light">
                        {p.medium} • {p.height}×{p.width} {p.unit}
                      </p>
                      <span className="text-sm font-serif italic text-[#c8a165] block mt-1">
                        {formatPrice(p.price)}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 mt-2">
                      {p.status === 'Available' ? (
                        <button
                          onClick={() => {
                            onClose();
                            onBuyNow(p);
                          }}
                          className="px-3 py-1 bg-[#c8a165] text-white text-[10px] uppercase font-bold tracking-wider flex items-center gap-1 cursor-pointer"
                        >
                          <ShoppingBag className="w-3 h-3" />
                          <span>Buy Now</span>
                        </button>
                      ) : (
                        <span className="text-[10px] text-rose-600 font-bold uppercase">SOLD</span>
                      )}

                      <button
                        onClick={() => onRemoveFromWishlist(p.id)}
                        className="p-1 text-neutral-400 hover:text-rose-500 ml-auto cursor-pointer"
                        title="Remove"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
