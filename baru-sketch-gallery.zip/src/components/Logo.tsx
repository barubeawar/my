import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showSubtitle?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 'md', showSubtitle = true }) => {
  const iconSizes = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-20 h-20',
  };

  const titleSizes = {
    sm: 'text-base md:text-lg tracking-[0.2em]',
    md: 'text-2xl md:text-3xl tracking-[0.25em]',
    lg: 'text-3xl md:text-5xl tracking-[0.28em]',
  };

  const galleryTextSizes = {
    sm: 'text-[8px] tracking-[0.25em]',
    md: 'text-[10px] md:text-[11px] tracking-[0.35em]',
    lg: 'text-xs md:text-sm tracking-[0.45em]',
  };

  const taglineSizes = {
    sm: 'text-[7px] tracking-[0.2em]',
    md: 'text-[8px] md:text-[9px] tracking-[0.3em]',
    lg: 'text-[10px] md:text-xs tracking-[0.38em]',
  };

  return (
    <div className={`inline-flex flex-col items-center select-none group cursor-pointer ${className}`}>
      {/* Artist Palette SVG Icon */}
      <div className={`relative mb-1 transition-transform duration-300 group-hover:scale-105 ${iconSizes[size]}`}>
        <svg
          viewBox="0 0 200 160"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-xs"
        >
          <defs>
            {/* Wooden Palette Gradient */}
            <linearGradient id="paletteWood" x1="20" y1="20" x2="180" y2="140" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#E2B770" />
              <stop offset="50%" stopColor="#C89647" />
              <stop offset="100%" stopColor="#966324" />
            </linearGradient>

            {/* Brush Swoosh Gradient */}
            <linearGradient id="swooshGrad" x1="80" y1="50" x2="190" y2="120" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FFF2A1" />
              <stop offset="25%" stopColor="#F9A825" />
              <stop offset="55%" stopColor="#00B4D8" />
              <stop offset="100%" stopColor="#0077B6" />
            </linearGradient>

            {/* Brush Handle Gradient */}
            <linearGradient id="brushHandle" x1="100" y1="20" x2="150" y2="90" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#3A2312" />
              <stop offset="100%" stopColor="#1A0F07" />
            </linearGradient>

            {/* Ferrule Metallic Gradient */}
            <linearGradient id="ferruleGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#D4AF37" />
              <stop offset="50%" stopColor="#FFF2A1" />
              <stop offset="100%" stopColor="#AA7A1E" />
            </linearGradient>

            <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
              <feDropShadow dx="1" dy="2" stdDeviation="2" floodOpacity="0.2" />
            </filter>
          </defs>

          {/* Dynamic Paint Swoosh / Arc */}
          <path
            d="M 85 70 C 110 30, 160 35, 185 65 C 195 78, 180 110, 125 105 C 105 103, 90 90, 85 70 Z"
            fill="url(#swooshGrad)"
            opacity="0.92"
          />
          <path
            d="M 95 65 C 120 35, 165 42, 188 78 C 175 105, 130 102, 105 85 Z"
            fill="#48CAE4"
            opacity="0.6"
          />

          {/* Wooden Palette Base */}
          <path
            d="M 110 20 C 150 20, 175 45, 170 85 C 165 125, 130 145, 80 140 C 35 135, 20 100, 25 60 C 30 25, 70 20, 110 20 Z"
            fill="url(#paletteWood)"
            stroke="#7A4E1B"
            strokeWidth="2.5"
            filter="url(#shadow)"
          />

          {/* Thumbhole */}
          <ellipse cx="140" cy="100" rx="12" ry="16" fill="#111111" opacity="0.85" transform="rotate(-15 140 100)" />
          <ellipse cx="140" cy="100" rx="10" ry="14" fill="none" stroke="#7A4E1B" strokeWidth="1.5" transform="rotate(-15 140 100)" />

          {/* Paint Swatches / Dollops on Palette */}
          {/* Yellow */}
          <circle cx="50" cy="50" r="8" fill="#F4D03F" stroke="#D4AC0D" strokeWidth="1" />
          <circle cx="48" cy="48" r="2.5" fill="#FFF" opacity="0.6" />

          {/* Orange */}
          <circle cx="75" cy="38" r="8" fill="#EB984E" stroke="#D35400" strokeWidth="1" />
          <circle cx="73" cy="36" r="2.5" fill="#FFF" opacity="0.6" />

          {/* Red */}
          <circle cx="105" cy="35" r="7.5" fill="#E74C3C" stroke="#C0392B" strokeWidth="1" />
          <circle cx="103" cy="33" r="2" fill="#FFF" opacity="0.6" />

          {/* Green */}
          <circle cx="42" cy="78" r="8" fill="#27AE60" stroke="#1E8449" strokeWidth="1" />
          <circle cx="40" cy="76" r="2.5" fill="#FFF" opacity="0.6" />

          {/* Blue */}
          <circle cx="52" cy="108" r="8.5" fill="#2980B9" stroke="#1B4F72" strokeWidth="1" />
          <circle cx="50" cy="106" r="2.5" fill="#FFF" opacity="0.6" />

          {/* Dark Brown */}
          <circle cx="80" cy="125" r="7.5" fill="#4A2306" stroke="#2C1402" strokeWidth="1" />
          <circle cx="78" cy="123" r="2" fill="#FFF" opacity="0.4" />

          {/* Crimson Red */}
          <circle cx="112" cy="122" r="7.5" fill="#900C3F" stroke="#581845" strokeWidth="1" />

          {/* Paintbrush laying across */}
          <g filter="url(#shadow)">
            {/* Handle */}
            <path d="M 155 25 L 105 105 L 98 98 L 148 18 Z" fill="url(#brushHandle)" />
            {/* Ferrule */}
            <path d="M 105 105 L 96 118 L 89 111 L 98 98 Z" fill="url(#ferruleGrad)" />
            {/* Bristles */}
            <path d="M 96 118 C 92 125, 82 130, 78 132 C 84 125, 87 116, 89 111 Z" fill="#2C1802" />
            <path d="M 82 130 C 80 131, 76 133, 72 132 C 77 127, 83 124, 85 122 Z" fill="#D4AC0D" opacity="0.8" />
          </g>
        </svg>
      </div>

      {/* Main Brand Name "BARU" */}
      <h1 className={`font-serif font-bold text-neutral-900 dark:text-neutral-100 uppercase text-center leading-none ${titleSizes[size]}`}>
        BARU
      </h1>

      {/* Subtitle / Gallery Name with Line Accent */}
      <div className="flex items-center justify-center gap-2 w-full mt-1">
        <span className="h-[1px] w-4 sm:w-6 bg-gradient-to-r from-transparent to-[#c8a165]/60" />
        <span className={`font-serif font-semibold uppercase text-[#c8a165] whitespace-nowrap ${galleryTextSizes[size]}`}>
          SKETCH GALLERY
        </span>
        <span className="h-[1px] w-4 sm:w-6 bg-gradient-to-l from-transparent to-[#c8a165]/60" />
      </div>

      {/* Tagline "PAINTING YOUR IMAGINATION" */}
      {showSubtitle && (
        <>
          <p className={`uppercase font-light tracking-[0.35em] text-neutral-600 dark:text-neutral-400 mt-1 text-center ${taglineSizes[size]}`}>
            PAINTING YOUR IMAGINATION
          </p>

          {/* Decorative Bottom Flourish for medium and large sizes */}
          {size !== 'sm' && (
            <div className="flex items-center justify-center mt-1 text-[#c8a165]/70">
              <svg viewBox="0 0 100 12" className="w-14 h-2 fill-current">
                <path d="M0,6 Q25,0 45,6 T90,6 M100,6 Q75,12 55,6 T10,6" fill="none" stroke="currentColor" strokeWidth="0.75" />
                <polygon points="50,2 53,6 50,10 47,6" fill="currentColor" />
              </svg>
            </div>
          )}
        </>
      )}
    </div>
  );
};


