import React, { useState } from 'react';
import { Phone, Mail, MapPin, Send, MessageCircle, Instagram, Facebook, Youtube, CheckCircle2, Clock } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('General Gallery Inquiry');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);

    const text = encodeURIComponent(
      `Hello Artist Vishal Kumar Baroliya!\nNew Contact Inquiry from Baru Sketch Gallery Website:\n\n` +
      `👤 Name: ${name}\n` +
      `📞 Phone: ${phone}\n` +
      `✉️ Email: ${email}\n` +
      `📌 Subject: ${subject}\n` +
      `💬 Message: ${message}`
    );

    window.open(`https://wa.me/918000917547?text=${text}`, '_blank');
  };

  return (
    <section id="contact" className="py-20 px-4 sm:px-6 lg:px-8 bg-[#f8f5ef] dark:bg-[#111111] transition-colors border-b border-[#c8a165]/20">
      <div className="max-w-7xl mx-auto space-y-12">
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <span className="text-[#c8a165] text-xs font-semibold tracking-[0.3em] uppercase block">
            Direct Studio Connection
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-light italic text-neutral-900 dark:text-neutral-100">
            Get In Touch With The Artist
          </h2>
          <p className="text-xs text-neutral-600 dark:text-neutral-400 font-light">
            Have a question about an available artwork, gallery visits, or custom orders? Reach out directly to Vishal Kumar Baroliya.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-start">
          {/* Contact Details Card */}
          <div className="bg-white dark:bg-[#161616] p-6 sm:p-8 border border-[#111111]/10 dark:border-[#c8a165]/20 space-y-8 shadow-xs">
            <div className="space-y-2">
              <span className="text-[10px] font-bold text-[#c8a165] uppercase tracking-[0.2em] block">
                Baru Sketch Gallery Studio
              </span>
              <h3 className="font-serif text-2xl font-light italic text-neutral-900 dark:text-neutral-100">
                Contact Information
              </h3>
            </div>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="p-3 border border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-[#c8a165] shrink-0">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <span className="block text-[10px] text-neutral-400 uppercase tracking-widest font-bold">Artist Phone & WhatsApp</span>
                  <a
                    href="tel:8000917547"
                    className="text-base font-serif italic text-neutral-900 dark:text-neutral-100 hover:text-[#c8a165]"
                  >
                    +91 8000917547
                  </a>
                  <span className="block text-[10px] text-emerald-600 font-medium">Instant WhatsApp response</span>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="p-3 border border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-[#c8a165] shrink-0">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <span className="block text-[10px] text-neutral-400 uppercase tracking-widest font-bold">Official Gallery Email</span>
                  <a
                    href="mailto:sketchartis007@gmail.com"
                    className="text-sm font-serif italic text-neutral-900 dark:text-neutral-100 hover:text-[#c8a165]"
                  >
                    sketchartis007@gmail.com
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="p-3 border border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-[#c8a165] shrink-0">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <span className="block text-[10px] text-neutral-400 uppercase tracking-widest font-bold">Studio Address</span>
                  <p className="text-xs font-light text-neutral-800 dark:text-neutral-200 leading-snug">
                    Masuda Road, Beawar, Rajasthan – 305901, India
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="p-3 border border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-[#c8a165] shrink-0">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <span className="block text-[10px] text-neutral-400 uppercase tracking-widest font-bold">Studio Hours</span>
                  <p className="text-xs font-light text-neutral-800 dark:text-neutral-200">
                    Monday – Saturday: 10:00 AM – 8:00 PM IST
                  </p>
                </div>
              </div>
            </div>

            {/* Social Media Links */}
            <div className="pt-6 border-t border-[#111111]/10 dark:border-[#c8a165]/20 space-y-3">
              <span className="block text-[10px] font-bold text-[#c8a165] uppercase tracking-widest">
                Connect On Social Media
              </span>
              <div className="flex items-center gap-3">
                <a
                  href="https://instagram.com/baru_sketch_gallery"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 border border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-[#c8a165] hover:bg-[#c8a165] hover:text-white transition-colors"
                  title="Instagram"
                >
                  <Instagram className="w-4 h-4" />
                </a>

                <a
                  href="https://facebook.com/barusketchgallery"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 border border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-[#c8a165] hover:bg-[#c8a165] hover:text-white transition-colors"
                  title="Facebook"
                >
                  <Facebook className="w-4 h-4" />
                </a>

                <a
                  href="https://youtube.com/@barusketchgallery"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 border border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-[#c8a165] hover:bg-[#c8a165] hover:text-white transition-colors"
                  title="YouTube"
                >
                  <Youtube className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Google Maps Studio Embed */}
            <div className="pt-2">
              <span className="block text-[10px] font-bold text-neutral-400 uppercase tracking-widest mb-2">
                Beawar Studio Location
              </span>
              <div className="w-full h-48 border border-[#111111]/10 dark:border-[#c8a165]/20">
                <iframe
                  title="Baru Sketch Gallery Location Beawar"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14343.890350438012!2d74.316880!3d26.103070!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396be43c39d846ed%3A0xa19c8f654b38d380!2sBeawar%2C%20Rajasthan%20305901!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen={false}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
              </div>
            </div>
          </div>

          {/* Interactive Inquiry Form */}
          <div className="bg-white dark:bg-[#161616] p-6 sm:p-8 border border-[#111111]/10 dark:border-[#c8a165]/20 space-y-6 shadow-xs">
            <h3 className="font-serif text-2xl font-light italic text-neutral-900 dark:text-neutral-100">
              Send Direct Message
            </h3>

            {submitted ? (
              <div className="py-12 text-center space-y-4 animate-fadeIn">
                <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
                <h4 className="font-serif text-xl font-light italic">Message Sent!</h4>
                <p className="text-xs text-neutral-500 max-w-xs mx-auto font-light">
                  Thank you, {name}. Your inquiry has been transmitted to artist Vishal Kumar Baroliya via WhatsApp.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="px-5 py-2 bg-[#c8a165] text-white font-bold text-[10px] uppercase tracking-widest"
                >
                  Send Another Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-[10px] uppercase font-bold tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Vikramaditya Roy"
                    className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-neutral-900 dark:text-neutral-100 text-xs focus:border-[#c8a165] focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] uppercase font-bold tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="e.g. 8000917547"
                      className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-neutral-900 dark:text-neutral-100 text-xs focus:border-[#c8a165] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase font-bold tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. vikram@example.com"
                      className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-neutral-900 dark:text-neutral-100 text-xs focus:border-[#c8a165] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                    Inquiry Subject
                  </label>
                  <select
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-neutral-900 dark:text-neutral-100 text-xs focus:border-[#c8a165] focus:outline-none"
                  >
                    <option value="General Gallery Inquiry">General Gallery Inquiry</option>
                    <option value="Custom Portrait Order">Custom Portrait Order</option>
                    <option value="Corporate / Interior Project">Corporate / Interior Project</option>
                    <option value="Framing & Shipping Details">Framing & Shipping Details</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-bold tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                    Your Message *
                  </label>
                  <textarea
                    rows={4}
                    required
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Write your message or inquiry details here..."
                    className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-neutral-900 dark:text-neutral-100 text-xs focus:border-[#c8a165] focus:outline-none"
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-[#c8a165] text-white text-[10px] tracking-[0.2em] uppercase font-bold hover:bg-[#b08b52] transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send Message To Artist</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
