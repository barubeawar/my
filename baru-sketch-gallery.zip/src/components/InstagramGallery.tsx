import React from 'react';
import { Instagram, Heart, ExternalLink } from 'lucide-react';

export const InstagramGallery: React.FC = () => {
  const posts = [
    {
      id: 'ig-1',
      imageUrl: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=600&q=80',
      likes: '1.2k',
      title: 'Charcoal Portrait Progress'
    },
    {
      id: 'ig-2',
      imageUrl: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=600&q=80',
      likes: '980',
      title: 'Pencil Sketch Detailing'
    },
    {
      id: 'ig-3',
      imageUrl: 'https://images.unsplash.com/photo-1501472312651-726afe119ff1?auto=format&fit=crop&w=600&q=80',
      likes: '2.4k',
      title: 'Oil Canvas Varnish Session'
    },
    {
      id: 'ig-4',
      imageUrl: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=600&q=80',
      likes: '1.8k',
      title: 'Gold Leaf Foil Application'
    },
    {
      id: 'ig-5',
      imageUrl: 'https://images.unsplash.com/photo-1582562124811-c09040d0a901?auto=format&fit=crop&w=600&q=80',
      likes: '890',
      title: 'Watercolor Lotus Wet-on-Wet'
    },
    {
      id: 'ig-6',
      imageUrl: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=600&q=80',
      likes: '3.1k',
      title: 'Beawar Studio Work in Progress'
    }
  ];

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-[#111111] text-white border-b border-[#c8a165]/20">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="space-y-1">
            <span className="text-[#c8a165] text-xs font-semibold tracking-[0.3em] uppercase block">
              @baru_sketch_gallery
            </span>
            <h2 className="font-serif text-3xl font-light italic text-white">
              Studio Moments On Instagram
            </h2>
          </div>

          <a
            href="https://instagram.com/baru_sketch_gallery"
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2.5 bg-[#c8a165] text-white text-[10px] tracking-[0.2em] uppercase font-bold hover:bg-[#b08b52] transition-colors flex items-center gap-2"
          >
            <Instagram className="w-3.5 h-3.5" />
            <span>Follow Artist</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>

        {/* Instagram Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {posts.map((post) => (
            <a
              key={post.id}
              href="https://instagram.com/baru_sketch_gallery"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative aspect-square overflow-hidden bg-[#161616] border border-[#c8a165]/20 block shadow-xs"
            >
              <img
                src={post.imageUrl}
                alt={post.title}
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />

              <div className="absolute inset-0 bg-[#111111]/80 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center text-white p-2 text-center">
                <Instagram className="w-5 h-5 text-[#c8a165] mb-1" />
                <span className="text-[10px] font-semibold flex items-center gap-1 text-[#c8a165]">
                  <Heart className="w-3 h-3 fill-rose-500 text-rose-500" />
                  {post.likes}
                </span>
                <span className="text-[9px] text-neutral-300 line-clamp-1 mt-1 font-light">
                  {post.title}
                </span>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};
