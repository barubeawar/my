import React, { useState } from 'react';
import { CustomCommissionRequest } from '../types';
import { Send, Upload, Sparkles, CheckCircle2, MessageCircle, Calendar, DollarSign, Palette, Image as ImageIcon } from 'lucide-react';

interface CustomArtworkSectionProps {
  onSubmitRequest: (req: Omit<CustomCommissionRequest, 'id' | 'createdAt' | 'status'>) => void;
}

export const CustomArtworkSection: React.FC<CustomArtworkSectionProps> = ({ onSubmitRequest }) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    referenceImageUrl: '',
    preferredSize: '18×24 inches',
    medium: 'Charcoal Portrait',
    description: '',
    budget: '₹10,000 - ₹25,000',
    deliveryDate: '',
  });

  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);

  const handleImageFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setImagePreview(result);
        setFormData({ ...formData, referenceImageUrl: result });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitRequest(formData);
    setSubmitted(true);

    // Auto open WhatsApp with custom portrait commission details
    const text = encodeURIComponent(
      `Hello Artist Vishal Kumar Baroliya!\nI want to order a custom artwork/portrait.\n\n` +
      `👤 Name: ${formData.name}\n` +
      `📞 Phone: ${formData.phone}\n` +
      `✉️ Email: ${formData.email}\n` +
      `📐 Size: ${formData.preferredSize}\n` +
      `🎨 Medium: ${formData.medium}\n` +
      `💰 Budget: ${formData.budget}\n` +
      `📅 Target Date: ${formData.deliveryDate || 'Flexible'}\n` +
      `📝 Details: ${formData.description}`
    );

    window.open(`https://wa.me/918000917547?text=${text}`, '_blank');
  };

  return (
    <section id="custom" className="py-20 px-4 sm:px-6 lg:px-8 bg-[#f8f5ef] dark:bg-[#111111] transition-colors border-b border-[#c8a165]/20">
      <div className="max-w-5xl mx-auto space-y-12">
        {/* Section Header */}
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <span className="text-[#c8a165] text-xs font-semibold tracking-[0.3em] uppercase block">
            Commissioned Portraits & Hand-Drawn Masterpieces
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-light italic text-neutral-900 dark:text-neutral-100">
            Order Custom Handmade Artwork
          </h2>
          <p className="text-xs text-neutral-600 dark:text-neutral-400 font-light leading-relaxed">
            Turn your cherished photos, family portraits, wedding memories, or custom art visions into an heirloom handmade painting by artist <span className="font-medium text-[#c8a165]">Vishal Kumar Baroliya</span>.
          </p>
        </div>

        {/* Custom Artwork Form Box */}
        <div className="bg-white dark:bg-[#161616] border border-[#111111]/10 dark:border-[#c8a165]/20 p-6 sm:p-10 shadow-xs">
          {submitted ? (
            <div className="text-center py-12 space-y-6 animate-fadeIn">
              <div className="w-12 h-12 border border-[#c8a165] text-[#c8a165] bg-[#f8f5ef] dark:bg-[#111111] flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-2xl font-light italic text-neutral-900 dark:text-neutral-100">
                Custom Request Submitted!
              </h3>
              <p className="max-w-md mx-auto text-xs text-neutral-600 dark:text-neutral-400 font-light">
                Thank you, {formData.name}. Your details have been submitted directly to artist Vishal Kumar Baroliya. WhatsApp chat has been initiated for quick reference confirmation.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="px-6 py-2.5 bg-[#c8a165] text-white text-[10px] tracking-[0.2em] uppercase font-bold hover:bg-[#b08b52] transition-colors"
              >
                Submit Another Custom Inquiry
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Personal Details */}
              <div>
                <h3 className="text-[10px] font-bold text-[#c8a165] uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-[#c8a165]"></span>
                  1. Contact Information
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. Ananya Sharma"
                      className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-neutral-900 dark:text-neutral-100 text-xs focus:border-[#c8a165] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                      Phone Number (WhatsApp) *
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="e.g. 9876543210"
                      className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-neutral-900 dark:text-neutral-100 text-xs focus:border-[#c8a165] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="e.g. ananya@example.com"
                      className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-neutral-900 dark:text-neutral-100 text-xs focus:border-[#c8a165] focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Artwork Specifications */}
              <div>
                <h3 className="text-[10px] font-bold text-[#c8a165] uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-[#c8a165]"></span>
                  2. Artwork Preferences
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                      Preferred Medium *
                    </label>
                    <select
                      value={formData.medium}
                      onChange={(e) => setFormData({ ...formData, medium: e.target.value })}
                      className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-neutral-900 dark:text-neutral-100 text-xs focus:border-[#c8a165] focus:outline-none"
                    >
                      <option value="Charcoal Portrait">Charcoal Portrait</option>
                      <option value="Pencil Sketch">Pencil Sketch (Graphite)</option>
                      <option value="Acrylic Painting">Acrylic Painting</option>
                      <option value="Oil Painting">Oil Painting</option>
                      <option value="Watercolor">Watercolor</option>
                      <option value="Custom Landscape">Custom Landscape</option>
                      <option value="Mixed Media">Mixed Media</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                      Preferred Size *
                    </label>
                    <select
                      value={formData.preferredSize}
                      onChange={(e) => setFormData({ ...formData, preferredSize: e.target.value })}
                      className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-neutral-900 dark:text-neutral-100 text-xs focus:border-[#c8a165] focus:outline-none"
                    >
                      <option value="8×10 inches">8 × 10 inches (Small Desk Frame)</option>
                      <option value="12×18 inches">12 × 18 inches (Standard Portrait)</option>
                      <option value="18×24 inches">18 × 24 inches (Popular Large)</option>
                      <option value="24×36 inches">24 × 36 inches (Grand Gallery Canvas)</option>
                      <option value="30×40 inches">30 × 40 inches (Masterpiece Wall Size)</option>
                      <option value="Custom Sizing">Custom Specific Sizing</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                      Estimated Budget Range
                    </label>
                    <select
                      value={formData.budget}
                      onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                      className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-neutral-900 dark:text-neutral-100 text-xs focus:border-[#c8a165] focus:outline-none"
                    >
                      <option value="₹5,000 - ₹10,000">₹5,000 - ₹10,000</option>
                      <option value="₹10,000 - ₹25,000">₹10,000 - ₹25,000</option>
                      <option value="₹25,000 - ₹50,000">₹25,000 - ₹50,000</option>
                      <option value="₹50,000+">₹50,000+ (Luxury Custom Canvas)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Reference Image Upload & URL */}
              <div>
                <h3 className="text-[10px] font-bold text-[#c8a165] uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-[#c8a165]"></span>
                  3. Reference Image & Description
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* File Upload / Preview Box */}
                  <div className="space-y-2">
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300">
                      Upload Reference Photo
                    </label>

                    <div className="border border-dashed border-[#111111]/20 dark:border-[#c8a165]/30 p-4 text-center hover:border-[#c8a165] transition-colors bg-[#f8f5ef] dark:bg-[#111111]">
                      {imagePreview ? (
                        <div className="space-y-2">
                          <img
                            src={imagePreview}
                            alt="Reference Preview"
                            className="max-h-40 mx-auto object-contain"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              setImagePreview(null);
                              setFormData({ ...formData, referenceImageUrl: '' });
                            }}
                            className="text-[10px] text-rose-600 underline font-medium"
                          >
                            Remove / Replace Image
                          </button>
                        </div>
                      ) : (
                        <label className="cursor-pointer flex flex-col items-center justify-center py-4">
                          <Upload className="w-6 h-6 text-[#c8a165] mb-2" />
                          <span className="text-xs font-medium text-neutral-700 dark:text-neutral-300">
                            Click to upload reference photo
                          </span>
                          <span className="text-[9px] text-neutral-400 mt-1">PNG, JPG, JPEG up to 10MB</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleImageFile}
                            className="hidden"
                          />
                        </label>
                      )}
                    </div>
                  </div>

                  {/* Target Date & Instructions */}
                  <div className="space-y-4">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                        Target Delivery Date / Occasion
                      </label>
                      <input
                        type="date"
                        value={formData.deliveryDate}
                        onChange={(e) => setFormData({ ...formData, deliveryDate: e.target.value })}
                        className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-neutral-900 dark:text-neutral-100 text-xs focus:border-[#c8a165] focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 mb-1">
                        Special Instructions / Details
                      </label>
                      <textarea
                        rows={3}
                        value={formData.description}
                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        placeholder="Describe specific background wishes, framing preferences, or anniversary notes..."
                        className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] text-neutral-900 dark:text-neutral-100 text-xs focus:border-[#c8a165] focus:outline-none"
                      ></textarea>
                    </div>
                  </div>
                </div>
              </div>

              {/* Submit CTA */}
              <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-[#111111]/10 dark:border-[#c8a165]/20">
                <div className="text-[10px] text-neutral-500 flex items-center gap-2">
                  <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
                  <span>Direct WhatsApp order preview will open upon submission</span>
                </div>

                <button
                  type="submit"
                  className="w-full sm:w-auto px-8 py-3 bg-[#c8a165] text-white text-[10px] tracking-[0.2em] uppercase font-bold hover:bg-[#b08b52] transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit Custom Request</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};
