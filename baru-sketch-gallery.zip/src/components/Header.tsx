import React, { useState, useEffect } from 'react';
import { Logo } from './Logo';
import {
  Search,
  Heart,
  MessageCircle,
  Sun,
  Moon,
  Menu,
  X,
  Palette,
  ShieldCheck,
  DollarSign,
  PhoneCall
} from 'lucide-react';

interface HeaderProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
  wishlistCount: number;
  onOpenWishlist: () => void;
  onOpenSearch: () => void;
  onOpenAdmin: () => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  currency: 'INR' | 'USD';
  setCurrency: (curr: 'INR' | 'USD') => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeSection,
  setActiveSection,
  wishlistCount,
  onOpenWishlist,
  onOpenSearch,
  onOpenAdmin,
  darkMode,
  setDarkMode,
  currency,
  setCurrency,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'shop', label: 'Shop' },
    { id: 'custom', label: 'Custom Artwork' },
    { id: 'about', label: 'About Artist' },
    { id: 'reviews', label: 'Reviews' },
    { id: 'faq', label: 'FAQ' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNavClick = (id: string) => {
    setActiveSection(id);
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#f8f5ef]/95 dark:bg-[#111111]/95 backdrop-blur-md shadow-xs border-b border-[#c8a165]/30 py-3'
          : 'bg-[#f8f5ef] dark:bg-[#111111] py-4 border-b border-[#c8a165]/20'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Left Section: Est 2018 badge + Navigation */}
        <div className="flex items-center gap-6">
          <span className="hidden xl:inline-block text-[10px] tracking-[0.3em] uppercase opacity-60 font-semibold text-neutral-600 dark:text-neutral-400">
            Est. 2018
          </span>
          <div onClick={() => handleNavClick('home')} className="lg:hidden">
            <Logo size="sm" />
          </div>
        </div>

        {/* Center Logo */}
        <div onClick={() => handleNavClick('home')} className="hidden lg:block cursor-pointer text-center">
          <Logo size="md" />
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center space-x-4 xl:space-x-6">
          {navItems.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`text-[11px] uppercase tracking-widest transition-colors font-medium ${
                  isActive
                    ? 'text-[#c8a165] font-bold border-b border-[#c8a165] pb-0.5'
                    : 'text-neutral-800 dark:text-neutral-200 hover:text-[#c8a165]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Right Actions & Buttons */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Search trigger */}
          <button
            onClick={onOpenSearch}
            aria-label="Search Paintings"
            className="p-2 rounded-full text-neutral-800 dark:text-neutral-200 hover:text-[#c8a165] transition-colors"
            title="Search Paintings"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Wishlist button */}
          <button
            onClick={onOpenWishlist}
            aria-label="View Wishlist"
            className="p-2 rounded-full text-neutral-800 dark:text-neutral-200 hover:text-[#c8a165] transition-colors relative"
            title="Wishlist"
          >
            <Heart className="w-4 h-4 text-[#c8a165]" />
            {wishlistCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-[#c8a165] text-white font-bold text-[8px] w-3.5 h-3.5 rounded-full flex items-center justify-center">
                {wishlistCount}
              </span>
            )}
          </button>

          {/* Currency Toggle */}
          <button
            onClick={() => setCurrency(currency === 'INR' ? 'USD' : 'INR')}
            className="hidden sm:flex items-center gap-1 px-2.5 py-1 text-[10px] uppercase tracking-wider font-bold rounded-sm border border-[#c8a165]/40 text-neutral-800 dark:text-neutral-200 hover:bg-[#c8a165] hover:text-white transition-colors"
            title="Toggle Currency (₹ / $)"
          >
            <DollarSign className="w-3 h-3 text-[#c8a165]" />
            <span>{currency}</span>
          </button>

          {/* Dark / Light Mode Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            aria-label="Toggle Theme"
            className="p-2 rounded-full text-neutral-800 dark:text-neutral-200 hover:text-[#c8a165] transition-colors"
            title="Toggle Dark / Light Mode"
          >
            {darkMode ? <Sun className="w-4 h-4 text-[#c8a165]" /> : <Moon className="w-4 h-4 text-neutral-800" />}
          </button>

          {/* WhatsApp Direct Order Button */}
          <a
            href="https://wa.me/918000917547?text=Hello%20Vishal%20Kumar%20Baroliya!%20I%20am%20interested%20in%20your%20artwork%20and%20custom%20portraits."
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:flex items-center gap-1.5 px-4 py-2 bg-[#25D366] text-white text-[10px] tracking-widest uppercase font-bold hover:bg-[#20bd5a] transition-colors shadow-xs"
            title="Chat on WhatsApp"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>WhatsApp</span>
          </a>

          {/* Artist Portal Trigger Button */}
          <button
            onClick={onOpenAdmin}
            className="hidden xl:flex items-center gap-1 text-[10px] uppercase tracking-widest text-[#c8a165] hover:underline px-2 py-1 font-bold"
            title="Artist Inventory & Orders Portal"
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Portal</span>
          </button>

          {/* Mobile Menu Toggle Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle Mobile Menu"
            className="p-2 lg:hidden text-neutral-800 dark:text-neutral-200"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#f8f5ef] dark:bg-[#111111] border-b border-amber-900/10 dark:border-amber-500/10 px-4 pt-3 pb-6 space-y-2 shadow-xl animate-fadeIn">
          <div className="grid grid-cols-2 gap-2 pt-2 pb-3 border-b border-neutral-200 dark:border-neutral-800">
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`text-left px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-amber-100 dark:bg-amber-900/40 text-amber-900 dark:text-amber-300 font-semibold'
                      : 'text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200/50 dark:hover:bg-neutral-800'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>

          <div className="flex flex-col gap-2 pt-2">
            <a
              href="https://wa.me/918000917547?text=Hello%20Vishal%20Kumar%20Baroliya!%20I%20am%20interested%20in%20your%20artwork."
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-2.5 bg-emerald-700 text-white rounded-lg text-sm font-medium"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Order on WhatsApp (8000917547)</span>
            </a>

            <div className="flex items-center justify-between pt-1">
              <button
                onClick={() => setCurrency(currency === 'INR' ? 'USD' : 'INR')}
                className="text-xs font-semibold px-3 py-1.5 rounded-lg border border-neutral-300 dark:border-neutral-700 text-neutral-800 dark:text-neutral-200"
              >
                Currency: <span className="text-amber-700 font-bold">{currency}</span>
              </button>

              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAdmin();
                }}
                className="flex items-center gap-1.5 text-xs text-amber-800 dark:text-amber-400 font-medium py-1.5"
              >
                <Palette className="w-4 h-4" />
                <span>Artist Admin Portal</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
