import React, { useState } from 'react';
import { Painting } from '../types';
import { Search, X, Eye, ShoppingBag } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  paintings: Painting[];
  onSelectPainting: (p: Painting) => void;
  currency: 'INR' | 'USD';
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  paintings,
  onSelectPainting,
  currency,
}) => {
  if (!isOpen) return null;

  const [query, setQuery] = useState('');

  const filtered = paintings.filter((p) => {
    const q = query.toLowerCase();
    return (
      p.name.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      p.medium.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q) ||
      p.tags.some((t) => t.toLowerCase().includes(q))
    );
  });

  const formatPrice = (priceInInr: number) => {
    if (currency === 'USD') {
      const usd = Math.round(priceInInr / 85);
      return `$${usd.toLocaleString()}`;
    }
    return `₹${priceInInr.toLocaleString('en-IN')}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 px-4 bg-black/80 backdrop-blur-sm animate-fadeIn overflow-y-auto">
      <div className="w-full max-w-2xl bg-white dark:bg-[#161616] p-6 shadow-2xl border border-[#111111]/20 dark:border-[#c8a165]/30 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#111111]/10 dark:border-[#c8a165]/20">
          <div className="flex items-center gap-2 flex-1 pr-4">
            <Search className="w-4 h-4 text-[#c8a165]" />
            <input
              type="text"
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search paintings (e.g. charcoal, tiger, landscape, oil)..."
              className="w-full text-sm font-light bg-transparent focus:outline-none text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400"
            />
          </div>
          <button onClick={onClose} className="p-2 border border-[#c8a165]/20 bg-[#f8f5ef] dark:bg-[#111111] text-[#c8a165] hover:bg-[#c8a165] hover:text-white transition-colors cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto space-y-3">
          {filtered.length === 0 ? (
            <p className="text-center text-xs text-neutral-500 py-8 font-light">
              No paintings matching "{query}". Try searching "Pencil", "Charcoal", "Portrait", or "Landscape".
            </p>
          ) : (
            filtered.map((p) => (
              <div
                key={p.id}
                onClick={() => {
                  onClose();
                  onSelectPainting(p);
                }}
                className="flex items-center gap-4 p-3 bg-[#f8f5ef] dark:bg-[#111111] border border-[#111111]/10 dark:border-[#c8a165]/20 hover:border-[#c8a165] cursor-pointer transition-colors"
              >
                <img
                  src={p.imageUrl}
                  alt={p.name}
                  className="w-14 h-14 object-cover border border-[#c8a165]/20 shrink-0"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1">
                  <h4 className="font-serif font-light italic text-sm text-neutral-900 dark:text-neutral-100">{p.name}</h4>
                  <p className="text-[10px] text-neutral-500 font-light">{p.category} • {p.medium}</p>
                </div>
                <div className="text-right">
                  <span className="font-serif italic text-[#c8a165] text-sm">
                    {formatPrice(p.price)}
                  </span>
                  <span className={`block text-[9px] font-bold uppercase tracking-wider ${p.status === 'Available' ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {p.status}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
