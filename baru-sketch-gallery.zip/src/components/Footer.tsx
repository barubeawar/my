import React, { useState } from 'react';
import { Logo } from './Logo';
import { Phone, Mail, MapPin, Instagram, Facebook, Youtube, ArrowUp, Send, Check } from 'lucide-react';

interface FooterProps {
  onNavClick: (id: string) => void;
  onOpenPolicy: (type: 'shipping' | 'privacy' | 'terms' | 'return') => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavClick, onOpenPolicy }) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail) {
      setSubscribed(true);
      setTimeout(() => setSubscribed(false), 3000);
      setNewsletterEmail('');
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#111111] text-neutral-300 pt-16 pb-8 border-t border-[#c8a165]/20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <Logo size="lg" />
            <p className="text-xs text-neutral-400 font-light leading-relaxed max-w-sm">
              Baru Sketch Gallery is a luxury fine art brand founded by artist <span className="text-[#c8a165] font-semibold">Vishal Kumar Baroliya</span>. Specializing in handmade sketches, charcoal portraits, realistic oil & acrylic paintings, and custom portrait commissions.
            </p>

            {/* Newsletter */}
            <div className="pt-2 space-y-2">
              <span className="text-[10px] font-bold text-[#c8a165] block uppercase tracking-[0.2em]">
                Subscribe To Gallery Private Preview
              </span>
              <form onSubmit={handleSubscribe} className="flex gap-2 max-w-sm">
                <input
                  type="email"
                  required
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  placeholder="Enter your email address..."
                  className="px-3.5 py-2 border border-[#c8a165]/30 bg-[#161616] text-xs text-white placeholder:text-neutral-500 focus:outline-none focus:border-[#c8a165] flex-1"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#c8a165] hover:bg-[#b08b52] text-white text-[10px] uppercase tracking-widest font-bold shadow flex items-center gap-1 cursor-pointer"
                >
                  {subscribed ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Send className="w-3 h-3" />}
                  <span>{subscribed ? 'Joined' : 'Join'}</span>
                </button>
              </form>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="font-serif font-light italic text-sm text-white uppercase tracking-wider">Quick Links</h4>
            <ul className="space-y-2 text-xs font-light text-neutral-400">
              <li><button onClick={() => onNavClick('home')} className="hover:text-[#c8a165] cursor-pointer">Home</button></li>
              <li><button onClick={() => onNavClick('gallery')} className="hover:text-[#c8a165] cursor-pointer">Gallery Collection</button></li>
              <li><button onClick={() => onNavClick('custom')} className="hover:text-[#c8a165] cursor-pointer">Custom Artwork</button></li>
              <li><button onClick={() => onNavClick('about')} className="hover:text-[#c8a165] cursor-pointer">About Artist</button></li>
              <li><button onClick={() => onNavClick('reviews')} className="hover:text-[#c8a165] cursor-pointer">Customer Reviews</button></li>
              <li><button onClick={() => onNavClick('faq')} className="hover:text-[#c8a165] cursor-pointer">FAQ</button></li>
              <li><button onClick={() => onNavClick('contact')} className="hover:text-[#c8a165] cursor-pointer">Contact Studio</button></li>
            </ul>
          </div>

          {/* Categories */}
          <div className="space-y-3">
            <h4 className="font-serif font-light italic text-sm text-white uppercase tracking-wider">Art Mediums</h4>
            <ul className="space-y-2 text-xs font-light text-neutral-400">
              <li>Pencil Sketch</li>
              <li>Charcoal Sketch</li>
              <li>Realistic Portrait</li>
              <li>Acrylic Canvas Painting</li>
              <li>Oil Painting</li>
              <li>Watercolor Painting</li>
              <li>Rajasthan Landscape</li>
            </ul>
          </div>

          {/* Studio Address */}
          <div className="space-y-3">
            <h4 className="font-serif font-light italic text-sm text-white uppercase tracking-wider">Studio Contact</h4>
            <div className="space-y-2 text-xs font-light text-neutral-400">
              <p className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[#c8a165]" />
                <span>+91 8000917547</span>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#c8a165]" />
                <span>sketchartis007@gmail.com</span>
              </p>
              <p className="flex items-start gap-2 leading-relaxed">
                <MapPin className="w-3.5 h-3.5 text-[#c8a165] shrink-0 mt-0.5" />
                <span>Masuda Road, Beawar, Rajasthan – 305901</span>
              </p>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <a href="https://instagram.com/baru_sketch_gallery" target="_blank" rel="noopener noreferrer" className="p-2 border border-[#c8a165]/30 bg-[#161616] hover:bg-[#c8a165] text-white transition-colors">
                <Instagram className="w-3.5 h-3.5 text-[#c8a165]" />
              </a>
              <a href="https://facebook.com/barusketchgallery" target="_blank" rel="noopener noreferrer" className="p-2 border border-[#c8a165]/30 bg-[#161616] hover:bg-[#c8a165] text-white transition-colors">
                <Facebook className="w-3.5 h-3.5 text-[#c8a165]" />
              </a>
              <a href="https://youtube.com/@barusketchgallery" target="_blank" rel="noopener noreferrer" className="p-2 border border-[#c8a165]/30 bg-[#161616] hover:bg-[#c8a165] text-white transition-colors">
                <Youtube className="w-3.5 h-3.5 text-[#c8a165]" />
              </a>
            </div>
          </div>
        </div>

        {/* Policies & Copyright Bottom Bar */}
        <div className="pt-8 border-t border-[#c8a165]/20 flex flex-col sm:flex-row items-center justify-between gap-4 text-[10px] text-neutral-500 font-light">
          <p>© {new Date().getFullYear()} Baru Sketch Gallery. Created by Artist Vishal Kumar Baroliya. All rights reserved.</p>

          <div className="flex items-center gap-4">
            <button onClick={() => onOpenPolicy('shipping')} className="hover:text-[#c8a165] cursor-pointer">Shipping Policy</button>
            <button onClick={() => onOpenPolicy('privacy')} className="hover:text-[#c8a165] cursor-pointer">Privacy Policy</button>
            <button onClick={() => onOpenPolicy('terms')} className="hover:text-[#c8a165] cursor-pointer">Terms & Conditions</button>
            <button onClick={() => onOpenPolicy('return')} className="hover:text-[#c8a165] cursor-pointer">Return Policy</button>
          </div>
        </div>
      </div>

      {/* Floating Back To Top Button */}
      <button
        onClick={scrollToTop}
        className="fixed bottom-6 right-6 z-40 p-3 border border-[#c8a165]/40 bg-[#111111] text-[#c8a165] shadow-xl hover:bg-[#c8a165] hover:text-white transition-all cursor-pointer"
        title="Back to top"
      >
        <ArrowUp className="w-4 h-4" />
      </button>
    </footer>
  );
};
