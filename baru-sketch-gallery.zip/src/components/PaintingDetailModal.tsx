import React, { useState } from 'react';
import { Painting } from '../types';
import {
  X,
  Heart,
  MessageCircle,
  Share2,
  ZoomIn,
  ShieldCheck,
  Truck,
  Award,
  CheckCircle2,
  AlertCircle,
  Maximize2,
  Copy,
  Check,
  ShoppingBag
} from 'lucide-react';

interface PaintingDetailModalProps {
  painting: Painting | null;
  onClose: () => void;
  onToggleWishlist: (id: string) => void;
  isWishlisted: boolean;
  currency: 'INR' | 'USD';
  onBuyNow: (painting: Painting) => void;
  onRequestCustom: () => void;
}

export const PaintingDetailModal: React.FC<PaintingDetailModalProps> = ({
  painting,
  onClose,
  onToggleWishlist,
  isWishlisted,
  currency,
  onBuyNow,
  onRequestCustom,
}) => {
  if (!painting) return null;

  const [zoomActive, setZoomActive] = useState(false);
  const [copied, setCopied] = useState(false);
  const [unitToggle, setUnitToggle] = useState<'inch' | 'cm'>('inch');

  const formatPrice = (priceInInr: number) => {
    if (currency === 'USD') {
      const usd = Math.round(priceInInr / 85);
      return `$${usd.toLocaleString()}`;
    }
    return `₹${priceInInr.toLocaleString('en-IN')}`;
  };

  const isSold = painting.status === 'Sold';

  const displayedDimensions = () => {
    if (unitToggle === 'cm') {
      const hCm = Math.round(painting.height * 2.54);
      const wCm = Math.round(painting.width * 2.54);
      return `${hCm} × ${wCm} cm`;
    }
    return `${painting.height} × ${painting.width} inches`;
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `${painting.name} by Vishal Kumar Baroliya`,
        text: `Check out this artwork at Baru Sketch Gallery: ${painting.name}`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const whatsappMessage = encodeURIComponent(
    `Hello Vishal Kumar Baroliya! I am interested in purchasing "${painting.name}" (Medium: ${painting.medium}, Size: ${painting.height}x${painting.width} ${painting.unit}, Price: ₹${painting.price.toLocaleString('en-IN')}) from Baru Sketch Gallery.`
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 overflow-y-auto bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-5xl bg-white dark:bg-[#141414] rounded-2xl shadow-2xl overflow-hidden border border-neutral-200 dark:border-neutral-800 my-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-white/90 dark:bg-neutral-900/90 text-neutral-800 dark:text-neutral-200 hover:bg-amber-600 hover:text-white transition-colors shadow-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 max-h-[85vh] overflow-y-auto">
          {/* Left Column: Image with Zoom */}
          <div className="relative bg-neutral-950 p-6 flex items-center justify-center min-h-[350px] lg:min-h-[500px]">
            <img
              src={painting.imageUrl}
              alt={painting.name}
              className={`max-h-[70vh] w-auto object-contain rounded-lg shadow-2xl transition-transform duration-500 ${
                zoomActive ? 'scale-150 cursor-zoom-out' : 'cursor-zoom-in hover:scale-105'
              }`}
              onClick={() => setZoomActive(!zoomActive)}
              referrerPolicy="no-referrer"
            />

            {/* Zoom Hint Overlay */}
            <button
              onClick={() => setZoomActive(!zoomActive)}
              className="absolute bottom-4 left-4 px-3 py-1.5 rounded-full bg-black/70 text-white text-xs font-medium flex items-center gap-1.5 backdrop-blur-md hover:bg-amber-600 transition-colors"
            >
              <ZoomIn className="w-4 h-4" />
              <span>{zoomActive ? 'Reset Zoom' : 'Click to Zoom'}</span>
            </button>

            {/* Status Badge */}
            <div className="absolute top-4 left-4">
              {isSold ? (
                <span className="px-3 py-1 rounded-full bg-rose-600 text-white font-bold text-xs tracking-wider uppercase shadow-lg flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4" />
                  <span>SOLD</span>
                </span>
              ) : (
                <span className="px-3 py-1 rounded-full bg-emerald-600 text-white font-bold text-xs tracking-wider uppercase shadow-lg flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>AVAILABLE</span>
                </span>
              )}
            </div>
          </div>

          {/* Right Column: Artwork Details & Actions */}
          <div className="p-6 sm:p-8 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              {/* Category & Artist */}
              <div>
                <div className="flex items-center justify-between text-xs text-amber-800 dark:text-amber-400 font-semibold uppercase tracking-wider">
                  <span>{painting.category}</span>
                  <span>Year: {painting.year}</span>
                </div>
                <h2 className="font-serif text-2xl sm:text-3xl font-bold text-neutral-900 dark:text-neutral-100 mt-1">
                  {painting.name}
                </h2>
                <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
                  By Master Artist <span className="font-medium text-neutral-800 dark:text-neutral-200">Vishal Kumar Baroliya</span>
                </p>
              </div>

              {/* Price & Dimensions Bar */}
              <div className="p-4 rounded-xl bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
                <div>
                  <span className="block text-xs text-neutral-400 uppercase tracking-wider font-semibold">Price</span>
                  <span className="text-2xl font-serif font-bold text-amber-900 dark:text-amber-300">
                    {formatPrice(painting.price)}
                  </span>
                </div>

                {/* Dimension & Unit Toggle */}
                <div className="text-right">
                  <div className="flex items-center justify-end gap-1 mb-1">
                    <span className="text-xs text-neutral-400 uppercase font-semibold">Dimensions:</span>
                    <button
                      onClick={() => setUnitToggle(unitToggle === 'inch' ? 'cm' : 'inch')}
                      className="text-[10px] px-1.5 py-0.5 rounded bg-amber-100 dark:bg-amber-900/50 text-amber-900 dark:text-amber-300 font-semibold"
                    >
                      {unitToggle} (toggle)
                    </button>
                  </div>
                  <span className="text-sm font-semibold text-neutral-800 dark:text-neutral-200">
                    {displayedDimensions()}
                  </span>
                </div>
              </div>

              {/* Artwork Specifications Table */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-2.5 rounded-lg bg-neutral-100/70 dark:bg-neutral-800/50">
                  <span className="block text-neutral-400 font-medium">Medium</span>
                  <span className="font-semibold text-neutral-800 dark:text-neutral-200">{painting.medium}</span>
                </div>
                <div className="p-2.5 rounded-lg bg-neutral-100/70 dark:bg-neutral-800/50">
                  <span className="block text-neutral-400 font-medium">Surface</span>
                  <span className="font-semibold text-neutral-800 dark:text-neutral-200">{painting.surface}</span>
                </div>
                <div className="p-2.5 rounded-lg bg-neutral-100/70 dark:bg-neutral-800/50">
                  <span className="block text-neutral-400 font-medium">Frame</span>
                  <span className="font-semibold text-neutral-800 dark:text-neutral-200">{painting.frame}</span>
                </div>
                <div className="p-2.5 rounded-lg bg-neutral-100/70 dark:bg-neutral-800/50">
                  <span className="block text-neutral-400 font-medium">Authenticity</span>
                  <span className="font-semibold text-amber-700 dark:text-amber-400">Signed Certificate Included</span>
                </div>
              </div>

              {/* Full Description */}
              <div>
                <h4 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-1">Artwork Story & Details</h4>
                <p className="text-xs sm:text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed">
                  {painting.description}
                </p>
              </div>

              {/* Sold Message Box */}
              {isSold && (
                <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/50 text-rose-800 dark:text-rose-300 text-xs sm:text-sm space-y-2">
                  <div className="flex items-center gap-2 font-bold">
                    <AlertCircle className="w-4 h-4 text-rose-600" />
                    <span>This original artwork has been sold to a collector.</span>
                  </div>
                  <p className="text-xs text-rose-700 dark:text-rose-400">
                    You can request artist Vishal Kumar Baroliya to create a new custom commission inspired by this piece!
                  </p>
                  <button
                    onClick={() => {
                      onClose();
                      onRequestCustom();
                    }}
                    className="mt-2 px-4 py-2 bg-rose-700 hover:bg-rose-800 text-white font-medium text-xs rounded-lg shadow-sm"
                  >
                    Request Custom Commission
                  </button>
                </div>
              )}

              {/* Authenticity Badge */}
              <div className="flex items-center gap-3 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs">
                <Award className="w-6 h-6 text-amber-600 dark:text-amber-400 shrink-0" />
                <div>
                  <span className="font-bold text-amber-900 dark:text-amber-300 block">Certificate of Authenticity</span>
                  <span className="text-neutral-600 dark:text-neutral-400 text-[11px]">Hand-signed & stamped by Vishal Kumar Baroliya upon dispatch.</span>
                </div>
              </div>
            </div>

            {/* Action Buttons Row */}
            <div className="space-y-3 pt-4 border-t border-neutral-200 dark:border-neutral-800">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {!isSold && (
                  <button
                    onClick={() => onBuyNow(painting)}
                    className="w-full py-3 bg-amber-800 hover:bg-amber-900 text-white font-semibold text-sm rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 active:scale-95"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>Buy Now (UPI / Card)</span>
                  </button>
                )}

                <a
                  href={`https://wa.me/918000917547?text=${whatsappMessage}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 active:scale-95 ${
                    isSold ? 'col-span-2' : ''
                  }`}
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Order on WhatsApp</span>
                </a>
              </div>

              {/* Secondary Wishlist & Share */}
              <div className="flex items-center justify-between gap-3 pt-2">
                <button
                  onClick={() => onToggleWishlist(painting.id)}
                  className={`flex-1 py-2 px-3 rounded-lg border text-xs font-medium flex items-center justify-center gap-2 transition-colors ${
                    isWishlisted
                      ? 'border-rose-500 bg-rose-50 text-rose-600 dark:bg-rose-950/30'
                      : 'border-neutral-200 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-rose-500 text-rose-500' : ''}`} />
                  <span>{isWishlisted ? 'In Wishlist' : 'Add to Wishlist'}</span>
                </button>

                <button
                  onClick={handleShare}
                  className="py-2 px-4 rounded-lg border border-neutral-200 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 text-xs font-medium flex items-center gap-2"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Share2 className="w-4 h-4" />}
                  <span>{copied ? 'Link Copied!' : 'Share'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
