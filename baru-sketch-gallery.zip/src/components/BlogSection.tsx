import React, { useState } from 'react';
import { BLOG_POSTS } from '../data/blogs';
import { BlogPost } from '../types';
import { Calendar, Clock, ArrowRight, X, BookOpen } from 'lucide-react';

export const BlogSection: React.FC = () => {
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#f8f5ef] dark:bg-[#111111] border-b border-[#c8a165]/20">
      <div className="max-w-7xl mx-auto space-y-12">
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <span className="text-[#c8a165] text-xs font-semibold tracking-[0.3em] uppercase block">
            Art Insights & Studio Journal
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-light italic text-neutral-900 dark:text-neutral-100">
            Art Care Guides & Behind the Scenes
          </h2>
          <p className="text-xs text-neutral-600 dark:text-neutral-400 font-light">
            Articles by artist Vishal Kumar Baroliya on fine art techniques, portrait selection, and preservation.
          </p>
        </div>

        {/* Blog Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {BLOG_POSTS.map((post) => (
            <div
              key={post.id}
              onClick={() => setSelectedPost(post)}
              className="group bg-white dark:bg-[#161616] overflow-hidden border border-[#111111]/10 dark:border-[#c8a165]/20 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div className="aspect-[16/9] overflow-hidden relative">
                  <img
                    src={post.imageUrl}
                    alt={post.title}
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <span className="absolute top-3 left-3 px-2.5 py-1 bg-[#111111] text-[#c8a165] border border-[#c8a165]/30 text-[9px] font-bold uppercase tracking-wider">
                    {post.category}
                  </span>
                </div>

                <div className="p-5 space-y-3">
                  <div className="flex items-center gap-3 text-[10px] text-neutral-400 uppercase tracking-wider font-light">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-[#c8a165]" />
                      {post.date}
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-[#c8a165]" />
                      {post.readTime}
                    </span>
                  </div>

                  <h3 className="font-serif text-lg font-light italic text-neutral-900 dark:text-neutral-100 group-hover:text-[#c8a165] transition-colors line-clamp-2">
                    {post.title}
                  </h3>

                  <p className="text-xs text-neutral-600 dark:text-neutral-400 line-clamp-3 font-light leading-relaxed">
                    {post.excerpt}
                  </p>
                </div>
              </div>

              <div className="p-5 pt-0">
                <span className="text-[10px] uppercase font-bold tracking-widest text-[#c8a165] flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  <span>Read Full Article</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Post Modal */}
      {selectedPost && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn overflow-y-auto">
          <div className="relative w-full max-w-3xl bg-white dark:bg-[#161616] p-6 sm:p-8 space-y-6 border border-[#111111]/20 dark:border-[#c8a165]/30 shadow-2xl my-auto">
            <button
              onClick={() => setSelectedPost(null)}
              className="absolute top-4 right-4 p-2 bg-[#111111] text-[#c8a165] border border-[#c8a165]/30 hover:bg-[#c8a165] hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="space-y-2">
              <span className="text-xs font-bold text-[#c8a165] uppercase tracking-[0.2em] block">
                {selectedPost.category}
              </span>
              <h2 className="font-serif text-2xl sm:text-3xl font-light italic">{selectedPost.title}</h2>
              <div className="flex items-center gap-4 text-xs text-neutral-400 border-b border-[#111111]/10 dark:border-[#c8a165]/20 pb-3 font-light">
                <span>By Artist Vishal Kumar Baroliya</span>
                <span>•</span>
                <span>{selectedPost.date}</span>
                <span>•</span>
                <span>{selectedPost.readTime}</span>
              </div>
            </div>

            <img
              src={selectedPost.imageUrl}
              alt={selectedPost.title}
              className="w-full h-64 object-cover border border-[#c8a165]/20"
              referrerPolicy="no-referrer"
            />

            <div className="text-xs text-neutral-700 dark:text-neutral-300 leading-relaxed font-light space-y-4">
              <p>{selectedPost.content}</p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
