import React, { useState } from 'react';
import { Review } from '../types';
import { Star, Quote, CheckCircle2, MessageSquare, Plus } from 'lucide-react';

interface TestimonialsProps {
  reviews: Review[];
  onAddReview: (rev: Omit<Review, 'id' | 'date' | 'verified'>) => void;
}

export const Testimonials: React.FC<TestimonialsProps> = ({ reviews, onAddReview }) => {
  const [showModal, setShowModal] = useState(false);
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [artworkName, setArtworkName] = useState('');
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddReview({ customerName: name, location, artworkName, rating, comment });
    setShowModal(false);
    setName('');
    setLocation('');
    setArtworkName('');
    setComment('');
  };

  return (
    <section id="reviews" className="py-20 px-4 sm:px-6 lg:px-8 bg-[#f8f5ef] dark:bg-[#111111] border-b border-[#c8a165]/20">
      <div className="max-w-7xl mx-auto space-y-12">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="space-y-1">
            <span className="text-[#c8a165] text-xs font-semibold tracking-[0.3em] uppercase block">
              Collector & Client Feedback
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-light italic text-neutral-900 dark:text-neutral-100">
              Customer Testimonials
            </h2>
          </div>

          <button
            onClick={() => setShowModal(true)}
            className="px-5 py-2.5 bg-[#c8a165] text-white text-[10px] tracking-[0.2em] uppercase font-bold hover:bg-[#b08b52] transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Write a Review</span>
          </button>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {reviews.map((rev) => (
            <div
              key={rev.id}
              className="bg-white dark:bg-[#161616] p-6 border border-[#111111]/10 dark:border-[#c8a165]/20 shadow-xs hover:shadow-md transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  {/* Star Rating */}
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3.5 h-3.5 ${
                          i < rev.rating ? 'fill-[#c8a165] text-[#c8a165]' : 'text-neutral-300 dark:text-neutral-700'
                        }`}
                      />
                    ))}
                  </div>
                  <Quote className="w-5 h-5 text-[#c8a165]/30" />
                </div>

                <p className="text-xs text-neutral-700 dark:text-neutral-300 leading-relaxed font-light italic">
                  "{rev.comment}"
                </p>
              </div>

              <div className="pt-3 border-t border-[#111111]/10 dark:border-[#c8a165]/20 flex items-center gap-3">
                {rev.avatarUrl ? (
                  <img
                    src={rev.avatarUrl}
                    alt={rev.customerName}
                    className="w-9 h-9 object-cover shrink-0"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-9 h-9 bg-[#111111] text-[#c8a165] border border-[#c8a165]/30 font-serif font-bold text-xs flex items-center justify-center shrink-0">
                    {rev.customerName.charAt(0)}
                  </div>
                )}

                <div>
                  <div className="flex items-center gap-1">
                    <span className="font-serif italic text-xs text-neutral-900 dark:text-neutral-100">{rev.customerName}</span>
                    {rev.verified && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" title="Verified Collector" />}
                  </div>
                  <span className="text-[10px] text-neutral-500 block font-light">{rev.location}</span>
                  {rev.artworkName && (
                    <span className="text-[10px] text-[#c8a165] font-semibold block truncate max-w-[150px]">
                      Piece: {rev.artworkName}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Write Review Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-white dark:bg-[#161616] p-6 space-y-4 border border-[#111111]/20 dark:border-[#c8a165]/30 shadow-2xl">
            <h3 className="font-serif text-xl font-light italic">Write a Review</h3>

            <form onSubmit={handleSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-[10px] uppercase font-bold tracking-wider mb-1">Your Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Priya Sharma"
                  className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111]"
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold tracking-wider mb-1">City / Location *</label>
                <input
                  type="text"
                  required
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. Jaipur, Rajasthan"
                  className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111]"
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold tracking-wider mb-1">Purchased Artwork Name</label>
                <input
                  type="text"
                  value={artworkName}
                  onChange={(e) => setArtworkName(e.target.value)}
                  placeholder="e.g. Charcoal Portrait"
                  className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111]"
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold tracking-wider mb-1">Rating *</label>
                <select
                  value={rating}
                  onChange={(e) => setRating(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111] font-semibold text-[#c8a165]"
                >
                  <option value={5}>⭐⭐⭐⭐⭐ (5 Stars)</option>
                  <option value={4}>⭐⭐⭐⭐ (4 Stars)</option>
                  <option value={3}>⭐⭐⭐ (3 Stars)</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold tracking-wider mb-1">Your Feedback *</label>
                <textarea
                  rows={3}
                  required
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Describe your experience with Baru Sketch Gallery..."
                  className="w-full px-3 py-2 border border-[#111111]/20 dark:border-[#c8a165]/30 bg-[#f8f5ef] dark:bg-[#111111]"
                ></textarea>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 border border-[#111111] dark:border-white/30 text-[9px] uppercase tracking-widest font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#c8a165] text-white text-[9px] uppercase tracking-widest font-bold hover:bg-[#b08b52]"
                >
                  Submit Review
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
