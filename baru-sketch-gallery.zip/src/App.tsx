import React, { useState, useEffect } from 'react';
import { Painting, CustomCommissionRequest, Review } from './types';
import { INITIAL_PAINTINGS } from './data/paintings';
import { INITIAL_REVIEWS } from './data/reviews';

import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { PaintingCard } from './components/PaintingCard';
import { PaintingDetailModal } from './components/PaintingDetailModal';
import { CustomArtworkSection } from './components/CustomArtworkSection';
import { CategoryGrid } from './components/CategoryGrid';
import { AboutArtist } from './components/AboutArtist';
import { Testimonials } from './components/Testimonials';
import { WhyChooseUs } from './components/WhyChooseUs';
import { InstagramGallery } from './components/InstagramGallery';
import { FaqAccordion } from './components/FaqAccordion';
import { BlogSection } from './components/BlogSection';
import { ContactSection } from './components/ContactSection';
import { UpiPaymentModal } from './components/UpiPaymentModal';
import { ArtistAdminPortal } from './components/ArtistAdminPortal';
import { WishlistDrawer } from './components/WishlistDrawer';
import { SearchModal } from './components/SearchModal';
import { PolicyModal } from './components/PolicyModals';
import { Footer } from './components/Footer';

import { Filter, SlidersHorizontal, ArrowUpDown, Sparkles, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  // Persistence state
  const [paintings, setPaintings] = useState<Painting[]>(() => {
    const saved = localStorage.getItem('baru_paintings');
    return saved ? JSON.parse(saved) : INITIAL_PAINTINGS;
  });

  const [reviews, setReviews] = useState<Review[]>(() => {
    const saved = localStorage.getItem('baru_reviews');
    return saved ? JSON.parse(saved) : INITIAL_REVIEWS;
  });

  const [commissionRequests, setCommissionRequests] = useState<CustomCommissionRequest[]>(() => {
    const saved = localStorage.getItem('baru_commission_requests');
    return saved ? JSON.parse(saved) : [];
  });

  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('baru_wishlist');
    return saved ? JSON.parse(saved) : ['art-001'];
  });

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('baru_theme') === 'dark';
  });

  const [currency, setCurrency] = useState<'INR' | 'USD'>('INR');

  // UI Modals & Views
  const [activeSection, setActiveSection] = useState('home');
  const [selectedPainting, setSelectedPainting] = useState<Painting | null>(null);
  const [paymentPainting, setPaymentPainting] = useState<Painting | null>(null);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [policyType, setPolicyType] = useState<'shipping' | 'privacy' | 'terms' | 'return' | null>(null);

  // Gallery Filters
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedMedium, setSelectedMedium] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Available' | 'Sold'>('All');
  const [sortBy, setSortBy] = useState<'newest' | 'price-asc' | 'price-desc'>('newest');

  // Sync dark mode class
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('baru_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('baru_theme', 'light');
    }
  }, [darkMode]);

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem('baru_paintings', JSON.stringify(paintings));
  }, [paintings]);

  useEffect(() => {
    localStorage.setItem('baru_reviews', JSON.stringify(reviews));
  }, [reviews]);

  useEffect(() => {
    localStorage.setItem('baru_commission_requests', JSON.stringify(commissionRequests));
  }, [commissionRequests]);

  useEffect(() => {
    localStorage.setItem('baru_wishlist', JSON.stringify(wishlistIds));
  }, [wishlistIds]);

  // Handlers
  const handleToggleWishlist = (id: string) => {
    setWishlistIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleUpdatePainting = (updated: Painting) => {
    setPaintings((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
  };

  const handleAddPainting = (newP: Painting) => {
    setPaintings((prev) => [newP, ...prev]);
  };

  const handleDeletePainting = (id: string) => {
    setPaintings((prev) => prev.filter((p) => p.id !== id));
  };

  const handleAddCustomRequest = (req: Omit<CustomCommissionRequest, 'id' | 'createdAt' | 'status'>) => {
    const newReq: CustomCommissionRequest = {
      ...req,
      id: `req-${Date.now()}`,
      createdAt: new Date().toLocaleDateString('en-IN'),
      status: 'Pending',
    };
    setCommissionRequests((prev) => [newReq, ...prev]);
  };

  const handleAddReview = (rev: Omit<Review, 'id' | 'date' | 'verified'>) => {
    const newRev: Review = {
      ...rev,
      id: `rev-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      verified: true,
    };
    setReviews((prev) => [newRev, ...prev]);
  };

  // Filtered Paintings List
  const filteredPaintings = paintings.filter((p) => {
    const matchCategory = selectedCategory === 'All' || p.category === selectedCategory;
    const matchMedium = selectedMedium === 'All' || p.medium === selectedMedium;
    const matchStatus = statusFilter === 'All' || p.status === statusFilter;
    return matchCategory && matchMedium && matchStatus;
  }).sort((a, b) => {
    if (sortBy === 'price-asc') return a.price - b.price;
    if (sortBy === 'price-desc') return b.price - a.price;
    return b.year - a.year; // newest
  });

  const featuredPaintings = paintings.filter((p) => p.featured || p.bestSeller);

  return (
    <div className="min-h-screen bg-[#f8f5ef] dark:bg-[#0d0d0d] text-[#111111] dark:text-[#f8f5ef] font-['Poppins',sans-serif] selection:bg-amber-500/30">
      {/* Header */}
      <Header
        activeSection={activeSection}
        setActiveSection={setActiveSection}
        wishlistCount={wishlistIds.length}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenAdmin={() => setIsAdminOpen(true)}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        currency={currency}
        setCurrency={setCurrency}
      />

      {/* Main Content Sections */}
      <main id="home">
        {/* Hero Section */}
        <Hero
          onExploreGallery={() => {
            setActiveSection('gallery');
            document.getElementById('gallery')?.scrollIntoView({ behavior: 'smooth' });
          }}
          onOrderCustom={() => {
            setActiveSection('custom');
            document.getElementById('custom')?.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* Featured Masterpieces Carousel/Grid */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-amber-800 dark:text-amber-400 uppercase tracking-widest block mb-1">
                Handpicked Signature Pieces
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold">
                Featured Masterpiece Artworks
              </h2>
            </div>

            <button
              onClick={() => {
                setSelectedCategory('All');
                document.getElementById('gallery')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="text-xs font-semibold text-amber-800 dark:text-amber-400 hover:underline"
            >
              Explore Full Collection →
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredPaintings.slice(0, 4).map((p) => (
              <PaintingCard
                key={p.id}
                painting={p}
                onSelect={(painting) => setSelectedPainting(painting)}
                onToggleWishlist={handleToggleWishlist}
                isWishlisted={wishlistIds.includes(p.id)}
                currency={currency}
                onBuyNow={(painting) => setPaymentPainting(painting)}
              />
            ))}
          </div>
        </section>

        {/* Category Visual Grid */}
        <CategoryGrid
          selectedCategory={selectedCategory}
          onSelectCategory={(cat) => {
            setSelectedCategory(cat);
            setActiveSection('gallery');
            document.getElementById('gallery')?.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* Main Gallery Collection & Filter Store */}
        <section id="gallery" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-10">
          <div className="text-center space-y-3 max-w-2xl mx-auto">
            <span className="text-xs font-bold text-amber-800 dark:text-amber-400 uppercase tracking-widest block">
              Online Painting Store & Catalog
            </span>
            <h2 id="shop" className="font-serif text-3xl sm:text-5xl font-bold">
              The Fine Art Gallery
            </h2>
            <p className="text-sm text-neutral-600 dark:text-neutral-400 font-light">
              Filter by medium, category, availability, or price. Every piece is 100% handmade and accompanies a signed Certificate of Authenticity.
            </p>
          </div>

          {/* Filter Bar Controls */}
          <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-[#161616] border border-neutral-200 dark:border-neutral-800 shadow-sm flex flex-col lg:flex-row items-center justify-between gap-4">
            {/* Category Pills */}
            <div className="flex items-center gap-2 overflow-x-auto w-full lg:w-auto pb-2 lg:pb-0 scrollbar-none">
              {['All', 'Pencil Sketch', 'Charcoal Sketch', 'Portrait', 'Acrylic Painting', 'Oil Painting', 'Watercolor', 'Landscape'].map(
                (cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                      selectedCategory === cat
                        ? 'bg-amber-800 text-white shadow-sm'
                        : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200'
                    }`}
                  >
                    {cat}
                  </button>
                )
              )}
            </div>

            {/* Dropdown Filters */}
            <div className="flex items-center gap-3 w-full lg:w-auto justify-end text-xs">
              {/* Availability Filter */}
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-3 py-2 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 font-medium"
              >
                <option value="All">Status: All Artworks</option>
                <option value="Available">Available Only (Green)</option>
                <option value="Sold">Sold Artworks (Red)</option>
              </select>

              {/* Sort By */}
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-3 py-2 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 font-medium"
              >
                <option value="newest">Sort: Newest First</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
              </select>
            </div>
          </div>

          {/* Gallery Items Grid */}
          {filteredPaintings.length === 0 ? (
            <div className="text-center py-16 bg-white dark:bg-[#161616] rounded-3xl border border-neutral-200 dark:border-neutral-800 space-y-3">
              <p className="text-base font-semibold text-neutral-800 dark:text-neutral-200">
                No artworks match your selected filters.
              </p>
              <button
                onClick={() => {
                  setSelectedCategory('All');
                  setSelectedMedium('All');
                  setStatusFilter('All');
                }}
                className="text-xs font-semibold text-amber-800 dark:text-amber-400 underline"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <AnimatePresence mode="wait">
              <motion.div
                key={`${selectedCategory}-${selectedMedium}-${statusFilter}-${sortBy}`}
                initial="hidden"
                animate="visible"
                exit="hidden"
                variants={{
                  hidden: { opacity: 0 },
                  visible: {
                    opacity: 1,
                    transition: {
                      staggerChildren: 0.05,
                    },
                  },
                }}
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              >
                {filteredPaintings.map((p) => (
                  <motion.div
                    key={p.id}
                    variants={{
                      hidden: { opacity: 0, y: 16 },
                      visible: {
                        opacity: 1,
                        y: 0,
                        transition: {
                          duration: 0.35,
                          ease: [0.22, 1, 0.36, 1],
                        },
                      },
                    }}
                    className="h-full"
                  >
                    <PaintingCard
                      painting={p}
                      onSelect={(painting) => setSelectedPainting(painting)}
                      onToggleWishlist={handleToggleWishlist}
                      isWishlisted={wishlistIds.includes(p.id)}
                      currency={currency}
                      onBuyNow={(painting) => setPaymentPainting(painting)}
                    />
                  </motion.div>
                ))}
              </motion.div>
            </AnimatePresence>
          )}
        </section>

        {/* Custom Artwork Commission Section */}
        <CustomArtworkSection onSubmitRequest={handleAddCustomRequest} />

        {/* About Artist Section */}
        <AboutArtist />

        {/* Testimonials */}
        <Testimonials reviews={reviews} onAddReview={handleAddReview} />

        {/* Why Choose Us */}
        <WhyChooseUs />

        {/* Instagram Gallery */}
        <InstagramGallery />

        {/* Blog / Art Care Section */}
        <BlogSection />

        {/* FAQ Accordion */}
        <FaqAccordion />

        {/* Contact Section */}
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer
        onNavClick={(id) => {
          setActiveSection(id);
          document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
        }}
        onOpenPolicy={(type) => setPolicyType(type)}
      />

      {/* Modals & Drawers */}
      <PaintingDetailModal
        painting={selectedPainting}
        onClose={() => setSelectedPainting(null)}
        onToggleWishlist={handleToggleWishlist}
        isWishlisted={selectedPainting ? wishlistIds.includes(selectedPainting.id) : false}
        currency={currency}
        onBuyNow={(p) => {
          setSelectedPainting(null);
          setPaymentPainting(p);
        }}
        onRequestCustom={() => {
          document.getElementById('custom')?.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      <UpiPaymentModal
        painting={paymentPainting}
        onClose={() => setPaymentPainting(null)}
        currency={currency}
      />

      {isAdminOpen && (
        <ArtistAdminPortal
          paintings={paintings}
          onUpdatePainting={handleUpdatePainting}
          onAddPainting={handleAddPainting}
          onDeletePainting={handleDeletePainting}
          commissionRequests={commissionRequests}
          onClose={() => setIsAdminOpen(false)}
          currency={currency}
        />
      )}

      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlistIds={wishlistIds}
        paintings={paintings}
        onRemoveFromWishlist={handleToggleWishlist}
        onSelectPainting={(p) => setSelectedPainting(p)}
        onBuyNow={(p) => setPaymentPainting(p)}
        currency={currency}
      />

      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        paintings={paintings}
        onSelectPainting={(p) => setSelectedPainting(p)}
        currency={currency}
      />

      <PolicyModal type={policyType} onClose={() => setPolicyType(null)} />
    </div>
  );
}
